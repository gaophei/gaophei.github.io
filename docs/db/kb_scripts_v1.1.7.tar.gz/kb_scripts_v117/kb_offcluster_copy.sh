#!/usr/bin/env bash
# ==============================================================================
# off-cluster 副本复制  kb_offcluster_copy.sh  v1.1.7
#   方案 C：受控窗口内【真正停止 repo 写入】后复制
#
# ⚠️ 必须在维护窗口执行。禁止对活动 repo 直接 rsync。
# 用法：bash kb_offcluster_copy.sh <目标主机> <目标基路径>
#   默认采用【时间戳新目录】模式：在 <目标基路径> 下新建 <主机>_<时间戳>/ 目录，
#   目标目录必然为空，因此无需 --delete，也就不存在误删风险。
#   如需刷新固定目录，见 REFRESH_MODE。
# 退出码：0 = 复制并校验通过   非 0 = 任一环节失败
#
# v1.1.4 修订（三项均为实测复现的 false-PASS）：
#   [P0] 静止窗口的 find 用 `2>/dev/null | head -5 || true`，把 find 自身的失败
#        （如 Permission denied、rc=2）吞成「无输出」→ 判 PASS。现改为捕获 find
#        返回码与 stderr，执行失败一律 ERROR。
#   [P0] 步骤 0 只判 `[ -d "$REPO" ]`。实测：一个【完全空的目录】也能一路走到
#        「复制完成并校验通过 / rc=0」—— 什么备份都没复制却宣告成功。现增加
#        repo 身份硬门：sys_rman.conf 可读 + repo 非空 + 挂载点身份断言
#        （防 /data 未挂载时误复制根盘下的同名空目录）。
#   [P0] 复制与校验的 rsync 均未加 --delete，**目标端独有的文件完全检测不到**，
#        而 `du -sb` 对 0 字节多余文件也无感（实测源/目标同为 6B 却不是镜像）。
#        默认改为【时间戳新目录 + 目标必须为空】；REFRESH_MODE 下要求目标存在
#        marker 文件并全程使用 --delete。
#   [P1] 无 lsof 时的分支逻辑写反：rc=0(有占用) 判 FAIL 会当场退出、走不到人工
#        确认；rc=1(无占用) 反而进入确认。现统一为：无 lsof 即 ERROR 阻断，
#        需人工风险接受时使用 ALLOW_NO_LSOF=yes 显式降级。
#   [P1] QUIET_SEC 增加正整数与区间校验（0 会直接削掉观察窗口这层证据）。
#
# v1.1.6 修订：
#   [P0] `lsof +D` 的 rc=1 被解释成「确认 repo 无文件被打开」—— **不成立**。
#        lsof 在「搜索任一部分失败」（权限不足、目录不可读、I/O 错误）时同样
#        返回 1。也就是说 rc=1 只能说明「没有成功证明有打开文件」，
#        不能证明「没有打开文件」。这违反本包自己的 fail-closed 原则，
#        而它恰是「活动 repo 能否复制」的安全门。
#        现改为**捕获 stderr 并三分**：扫描完整且 0 个打开文件 → PASS；
#        发现打开文件 → FAIL；扫描不完整 / 权限或 I/O 错误 → ERROR。
#   [P1] REFRESH_MODE 的 marker 会被自身的 `rsync --delete` 删除 ——
#        marker 不存在于源 repo，首次刷新即被当作「目标端独有文件」删掉，
#        导致**第二次刷新无法通过自己的 marker 检查**。
#        现在所有 rsync（含预演与校验）统一 `--exclude=/<marker>`。
#
# v1.1.7 修订（两项都是【安全方向的假 FAIL】：会误挡，不会误放）：
#   [P1] 步骤 4 的字节比对用 `du -sb`，而 `du` 统计的是**目录本身的元数据 +
#        所有文件**：① REFRESH_MODE 下目标端多出的 marker 文件被计入目标侧，
#        而文件数比对已经排除了它 —— 两侧口径不一致，**刷新模式几乎必然 FAIL**；
#        ② 目录的 apparent size 在不同文件系统 / 目录项数量下本就不保证相等。
#        结果是：带 --delete 的 dry-run 为空、文件数一致、数据文件全部一致，
#        却因几十字节的目录元数据差异判定"字节数不一致"而终止。
#        现改为**只累计普通文件的字节数，两端都排除 marker**。
#   [P2] 静止窗口的 `find ... | head -5` 在 `set -o pipefail` 下：最近修改的
#        文件很多时 head 提前关闭管道，GNU find 收到 SIGPIPE，管道返回 141，
#        脚本把"repo 明显仍在变化"报成 **ERROR（证据缺失）**而不是 FAIL。
#        仍然阻断，但状态语义不准确。现改为判定用 `-print -quit`（命中即停），
#        展示用的列表放在显式关闭 pipefail 的子 shell 中。
# ==============================================================================
set -Eeuo pipefail
trap 'echo "★ 第 $LINENO 行失败，已中止（未完成的复制不可视为成功）" >&2; exit 1' ERR

SDIR=$(dirname "$(readlink -f "$0")")
. "$SDIR/kb_lib.sh" || { echo "缺少 kb_lib.sh"; exit 1; }

[ $# -eq 2 ] || { echo "用法: $0 <目标主机> <目标基路径>"; exit 2; }
DST_HOST=$1; DST_BASE=$2
KB_HOME=${KB_HOME:-/home/kingbase/cluster/kingbase}
REPO=${REPO:-/data/kingbase/backup/rman}
QUIET_SEC=${QUIET_SEC:-30}
ALLOW_NO_LSOF=${ALLOW_NO_LSOF:-no}      # 无 lsof 时是否允许人工降级
REFRESH_MODE=${REFRESH_MODE:-no}        # yes = 刷新固定目录（需 marker + --delete）
MARKER=.kb_offcluster_repo
# ★ repo 期望所在的挂载点；置空则跳过该断言（不推荐）
#   ⚠️ 本项与【三容量域方案】直接耦合，必须按现场实际取值，否则每次都被硬门挡下：
#     · 存储改造前的现场版：repo 仍在根盘 → EXPECT_REPO_MOUNT=/
#     · 建议版（独立备份卷挂 /data）        → EXPECT_REPO_MOUNT=/data
#     · 建议版（独立备份卷挂 /data/kingbase/backup）→ EXPECT_REPO_MOUNT=/data/kingbase/backup
#   现场取值：findmnt -no TARGET -T "$REPO"
EXPECT_REPO_MOUNT=${EXPECT_REPO_MOUNT:-/data}

TS=$(date +%Y%m%d_%H%M%S)
DRY=$HOME/offcopy-dry.$TS.log
VER=$HOME/offcopy-verify.$TS.log
ERRF=$(mktemp /tmp/kb_offcopy.err.XXXXXX)
trap 'rm -f "$ERRF"' EXIT

echo "===== off-cluster 副本复制 v1.1.7  $(date '+%F %T') ====="
echo "  源: $REPO"

# ==============================================================================
# 步骤 0：执行前硬门
# ==============================================================================
echo
echo "----- 步骤 0：执行前硬门 -----"
# ★ v1.1.7：不再依赖 du（字节比对已改为 find -printf 累计）；补入 findmnt ——
#   它是挂载点身份断言的取证命令，缺失时原先只会报"无法确定挂载点"。
for c in pgrep rsync ssh awk df find findmnt readlink mktemp; do
    command -v "$c" >/dev/null 2>&1 || { echo "★ ERROR: 缺少必需命令 $c，终止" >&2; exit 1; }
done

case "$QUIET_SEC" in ''|*[!0-9]*) echo "★ ERROR: QUIET_SEC 必须为正整数" >&2; exit 1;; esac
if [ "$QUIET_SEC" -lt 10 ] || [ "$QUIET_SEC" -gt 300 ]; then
    echo "★ ERROR: QUIET_SEC=$QUIET_SEC 超出允许区间 [10,300]" >&2; exit 1
fi

# ---- 源 repo 身份硬门（★ 防「空目录也宣告成功」）----
[ -d "$REPO" ] || { echo "★ ERROR: repo 目录不存在：$REPO" >&2; exit 1; }
[ -r "$REPO/sys_rman.conf" ] || {
    echo "★ ERROR: $REPO/sys_rman.conf 不可读 —— 该路径不是有效的 sys_rman repo" >&2
    echo "         （/data 未挂载时，根盘下的同名空目录会长这样）" >&2; exit 1; }
if ! find "$REPO" -mindepth 1 -print -quit 2>"$ERRF" | grep -q .; then
    echo "★ ERROR: repo 为空或无法列出内容：$(head -1 "$ERRF")" >&2; exit 1
fi
# ---- 挂载点身份断言（★ 防 /data 未挂载而误复制根盘同名目录）----
if [ -n "$EXPECT_REPO_MOUNT" ]; then
    ACTUAL_MNT=$(findmnt -no TARGET -T "$REPO" 2>/dev/null || true)
    if [ -z "$ACTUAL_MNT" ]; then
        echo "★ ERROR: 无法确定 $REPO 的挂载点" >&2; exit 1
    elif [ "$ACTUAL_MNT" != "$EXPECT_REPO_MOUNT" ]; then
        echo "★ ERROR: repo 实际挂载点为 [$ACTUAL_MNT]，期望 [$EXPECT_REPO_MOUNT]" >&2
        echo "         若 $EXPECT_REPO_MOUNT 未挂载，此刻复制的将是根盘下的同名目录。" >&2
        echo "         确属预期请显式设置 EXPECT_REPO_MOUNT。" >&2; exit 1
    fi
    echo "  repo 挂载点断言通过：$ACTUAL_MNT"
fi
NFILES=$(find "$REPO" -type f 2>/dev/null | wc -l)
echo "  repo 有效（sys_rman.conf 存在，含 $NFILES 个文件）"

# ---- lsof 可用性（★ 无 lsof 默认阻断，不再靠 WARN 自动继续）----
if command -v lsof >/dev/null 2>&1; then
    HAVE_LSOF=1; echo "  lsof 可用（可精确判定 repo 目录占用）"
elif [ "$ALLOW_NO_LSOF" = yes ]; then
    HAVE_LSOF=0
    echo "  ⚠️ 无 lsof，已由 ALLOW_NO_LSOF=yes 显式降级为 fuser -m（范围是整个文件系统）"
else
    echo "★ ERROR: 本机无 lsof，无法精确判定 repo 目录占用。" >&2
    echo "         建议安装 lsof；如已人工确认风险，用 ALLOW_NO_LSOF=yes 显式降级。" >&2
    exit 1
fi

# ==============================================================================
# check_repo_frozen <阶段名>  —— 全部使用 if 上下文，避免 ERR trap
# ==============================================================================
check_repo_frozen(){
  local phase=$1 rc M1
  KB_P=0; KB_F=0; KB_W=0; KB_E=0
  echo
  echo "----- 静止检查【$phase】-----"

  if pgrep -af 'sys_rman|backup8\.sh' >/dev/null 2>&1; then rc=0; else rc=$?; fi
  case $rc in
    0) say FAIL "仍有备份进程在运行"; pgrep -af 'sys_rman|backup8\.sh' || true ;;
    1) say PASS "无 sys_rman / backup8.sh 进程（pgrep 确认）" ;;
    *) say ERROR "pgrep 执行异常(rc=$rc)" ;;
  esac

  if [ "$HAVE_LSOF" = 1 ]; then
      # ★ v1.1.6：rc=1 既可能是「无打开文件」，也可能是「搜索部分失败」。
      #   必须结合 stderr 判断扫描是否完整，否则取证失败会被当成"确认无占用"。
      local lout lerr
      lerr=$(mktemp /tmp/kb_lsof.err.XXXXXX)
      if lout=$(lsof +D "$REPO" 2>"$lerr"); then rc=0; else rc=$?; fi
      if [ -s "$lerr" ]; then
          say ERROR "lsof 扫描不完整（stderr 非空）—— 无法确认 repo 占用：$(head -1 "$lerr")"
      else
          case $rc in
            0) say FAIL "repo 目录内有文件被进程打开"
               printf '%s\n' "$lout" | head -10 ;;
            1) say PASS "repo 目录内无文件被打开（lsof +D 扫描完整）" ;;
            *) say ERROR "lsof 执行异常(rc=$rc)" ;;
          esac
      fi
      rm -f "$lerr"
  else
      if fuser -sm "$REPO" >/dev/null 2>&1; then rc=0; else rc=$?; fi
      case $rc in
        0) say FAIL "fuser -m 报告占用（范围为整个文件系统）—— 已降级模式，须人工排除后重试" ;;
        1) say PASS "所在文件系统无占用（fuser -m，范围大于目录本身）" ;;
        *) say ERROR "fuser 执行异常(rc=$rc)" ;;
      esac
  fi

  if pgrep -x kingbase >/dev/null 2>&1; then rc=0; else rc=$?; fi
  case $rc in
    0) say FAIL "数据库仍在运行 —— archive_mode=always 会持续写 repo" ;;
    1) say PASS "数据库已停止（pgrep 确认）" ;;
    *) say ERROR "pgrep 执行异常(rc=$rc)" ;;
  esac

  if OUT=$(kb_paused "$KB_HOME/bin/repmgr"); then
      read -r pcol nn nyes nno <<<"$OUT"
      if   [ "${pcol:-0}" -eq 0 ] || [ "${nn:-0}" -eq 0 ]; then say ERROR "repmgr 输出无法解析"
      elif [ $((nyes+nno)) -ne "$nn" ];  then say ERROR "Paused 列存在无法识别的值"
      elif [ "$nyes" -eq "$nn" ];        then say PASS  "$nn 个节点全部 Paused=yes"
      else say FAIL "仅 $nyes/$nn 节点 Paused=yes —— 请先 repmgr service pause"; fi
  else say ERROR "repmgr service status 执行失败"; fi

  # ★ 观察窗口：必须先确认 find 执行成功，才能把「无输出」解释成「无修改」
  #   v1.1.7：判定用 -print -quit（命中一个即停），不再经过 head ——
  #   pipefail 下 head 提前关闭管道会让 find 收到 SIGPIPE(rc=141)，
  #   把「仍在变化」误报成 ERROR。
  if M1=$(find "$REPO" -newermt "-${QUIET_SEC} seconds" -print -quit 2>"$ERRF"); then
      if [ -n "$M1" ]; then
          say FAIL "repo 最近 ${QUIET_SEC}s 内仍有文件被修改 —— 未静止"
          # 仅用于展示：显式关闭 pipefail，head 早关管道不参与任何判定
          ( set +o pipefail
            find "$REPO" -newermt "-${QUIET_SEC} seconds" \
                 -printf '%TY-%Tm-%Td %TH:%TM:%.2TS  %p\n' 2>/dev/null \
              | sort -r | head -5 | sed 's/^/           /' ) || true
      else
          say PASS "repo 最近 ${QUIET_SEC}s 内无文件修改"
      fi
  else
      say ERROR "find 扫描 repo 失败：$(head -1 "$ERRF")"
  fi

  kb_summary "静止检查【$phase】"
}

check_repo_frozen "预检" || { echo "★ 预检未通过，终止。" >&2; exit 1; }

# ==============================================================================
# 步骤 1：确定目标目录（默认时间戳新目录，避免 --delete 的误删风险）
# ==============================================================================
echo
echo "----- 步骤 1：确定目标目录 -----"
case "$DST_BASE" in /|/home|/root|/etc|/usr|/var|/boot) echo "★ ERROR: 拒绝危险目标路径：$DST_BASE" >&2; exit 1;; esac

if [ "$REFRESH_MODE" = yes ]; then
    DST_PATH="$DST_BASE"
    RSYNC_DEL=(--delete "--exclude=/$MARKER")   # ★ marker 不在源 repo 中，必须排除否则会被 --delete 删掉
    echo "  模式：刷新固定目录 $DST_PATH（启用 --delete）"
    ssh -o BatchMode=yes -o ConnectTimeout=10 "$DST_HOST" "test -f '$DST_PATH/$MARKER'" 2>/dev/null || {
        echo "★ ERROR: 目标缺少 marker 文件 $DST_PATH/$MARKER" >&2
        echo "         刷新模式会 --delete 目标端多余文件，必须先在目标目录放置 marker 以确认身份：" >&2
        echo "         ssh $DST_HOST \"mkdir -p '$DST_PATH' && touch '$DST_PATH/$MARKER'\"" >&2
        exit 1; }
    echo "  marker 校验通过"
else
    DST_PATH="$DST_BASE/$(hostname -s)_$TS"
    RSYNC_DEL=("--exclude=/$MARKER")            # 非刷新模式也统一排除，保持三处 rsync 参数一致
    echo "  模式：新建时间戳目录 $DST_PATH（目标必为空，无需 --delete）"
fi

KB_P=0; KB_F=0; KB_W=0; KB_E=0
if ssh -o BatchMode=yes -o ConnectTimeout=10 "$DST_HOST" "mkdir -p '$DST_PATH' && test -w '$DST_PATH'" 2>/dev/null; then
    say PASS "目标可达且可写：$DST_HOST:$DST_PATH"
else
    say ERROR "目标不可达或不可写：$DST_HOST:$DST_PATH（免密是否配置？）"
fi
if [ "$REFRESH_MODE" != yes ]; then
    if N=$(ssh -o BatchMode=yes "$DST_HOST" "find '$DST_PATH' -mindepth 1 | wc -l" 2>/dev/null); then
        [ "$N" -eq 0 ] && say PASS "目标目录为空（$N 项）" \
                       || say FAIL "★ 目标目录非空（$N 项）—— 非刷新模式要求目标为空，否则残留文件无法检出"
    else say ERROR "无法确认目标目录是否为空"; fi
fi
kb_summary "目标检查" || { echo "★ 目标不可用，终止。" >&2; exit 1; }

# ==============================================================================
# 步骤 2：预演
# ==============================================================================
echo
echo "----- 步骤 2：预演 -----"
rsync -aHAX --numeric-ids "${RSYNC_DEL[@]}" --dry-run --itemize-changes "$REPO/" "$DST_HOST:$DST_PATH/" | tee "$DRY"
echo "预演日志：$DRY"
read -r -p "确认继续实际复制？(yes/no) " a
[ "$a" = yes ] || { echo "已取消。"; exit 3; }

# ★ TOCTOU 防护：人工确认耗时不定，实际复制前必须重新确认仍然静止
check_repo_frozen "实际复制前复检" || { echo "★ 复检未通过（确认期间状态已变化），终止。" >&2; exit 1; }

# ==============================================================================
# 步骤 3：复制
# ==============================================================================
echo
echo "----- 步骤 3：复制（失败即非零退出）-----"
rsync -aHAX --numeric-ids "${RSYNC_DEL[@]}" "$REPO/" "$DST_HOST:$DST_PATH/"
echo "rsync 返回 0"

check_repo_frozen "复制完成后复检" || { echo "★ 复制期间 repo 状态发生变化，副本不可信，终止。" >&2; exit 1; }

# ==============================================================================
# 步骤 4：校验（★ 必须能检出目标端独有文件）
# ==============================================================================
echo
echo "----- 步骤 4：校验 -----"
# ★ 校验一律带 --delete --dry-run：不带时【目标端独有的文件不会出现在输出中】，
#   而 du -sb 对 0 字节多余文件同样无感（实测源/目标同为 6B 却不是镜像）。
#   此处只是 dry-run，不会真的删除。
rsync -aHAX --numeric-ids --delete "--exclude=/$MARKER" --dry-run --itemize-changes "$REPO/" "$DST_HOST:$DST_PATH/" > "$VER"
if [ -s "$VER" ]; then
    echo "★ 校验未通过：源与目标不是镜像，见 $VER" >&2
    head -20 "$VER" >&2
    exit 1
fi
echo "✓ 带 --delete 的 dry-run 输出为空（含目标端独有文件检查）"

# ★ v1.1.7：字节比对只累计【普通文件】，两端都排除 marker。
#   不能用 du -sb：它把目录自身的 apparent size 也算进去（不同文件系统、
#   不同目录项数量下并不相等），且目标端的 marker 会被计入 —— 而文件数比对
#   已经排除了 marker，两侧口径不一致会造成刷新模式必然"字节数不一致"。
SUM='{s+=$1} END{printf "%d\n", s+0}'
if ! SRC_B=$(find "$REPO" -type f ! -name "$MARKER" -printf '%s\n' 2>"$ERRF" | awk "$SUM"); then
    echo "★ ERROR: 统计源字节数失败：$(head -1 "$ERRF")" >&2; exit 1
fi
if ! DST_B=$(ssh -o BatchMode=yes "$DST_HOST" \
        "find '$DST_PATH' -type f ! -name '$MARKER' -printf '%s\\n'" 2>"$ERRF" | awk "$SUM"); then
    echo "★ ERROR: 统计目标字节数失败：$(head -1 "$ERRF")" >&2; exit 1
fi
SRC_N=$(find "$REPO" -type f ! -name "$MARKER" | wc -l)
DST_N=$(ssh -o BatchMode=yes "$DST_HOST" "find '$DST_PATH' -type f ! -name '$MARKER' | wc -l")
echo "  源 ${SRC_B}B / ${SRC_N} 文件    目标 ${DST_B}B / ${DST_N} 文件（两端均已排除 $MARKER）"
[ "$SRC_B" = "$DST_B" ] || { echo "★ 字节数不一致（普通文件累计）" >&2; exit 1; }
[ "$SRC_N" = "$DST_N" ] || { echo "★ 文件数不一致" >&2; exit 1; }
echo "✓ 字节数与文件数均一致（口径：普通文件，排除 marker）"

echo
echo "===== 复制完成并校验通过：$DST_HOST:$DST_PATH ====="
echo "⚠️ 校验只证明【镜像一致】，不证明【可恢复】—— 最终仍须 restore 演练闭环。"
echo "⚠️ 恢复业务前请执行： repmgr service unpause  并确认 Paused = no"
exit 0
