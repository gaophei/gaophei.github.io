#!/usr/bin/env bash
# ==============================================================================
# 数据库日志清理  kb_log_cleanup.sh  v1.1.7
#   log_truncate_on_rotation 只覆盖同名文件，不负责保留期 —— 轮转 ≠ 保留
#
# 用法：bash kb_log_cleanup.sh [日志目录]      （kingbase 身份）
# 退出码：0 = 正常   非 0 = 参数非法 / 目录不合规 / 删除出错 / 空间告警
#
# v1.1.2 修订（本脚本执行 delete，输入校验必须最严）：
#   [P0] KEEP_DAYS 未做任何校验。实测 KEEP_DAYS=-1 时 `find -mtime +-1` 会匹配
#        【当天文件】，把刚生成的数据库日志全部删除，且返回 0。现增加正整数与
#        合理区间硬校验。
#   [P0] ALLOW_PREFIX 原可由环境变量任意覆盖（ALLOW_PREFIX=/ 即可绕过全部保护）。
#        改为脚本内固定，不接受环境变量。
#   [P1] `find ... -print -delete | tee /dev/stderr | wc -l` 中的 tee 会以 O_TRUNC
#        重新打开 stderr 指向的文件 —— cron 用 `>> log 2>&1` 时会【截断自己的
#        历史日志】（实测 PREEXISTING 行消失）。改用临时文件。
#
# v1.1.4 修订：
#   [P1] USED_WARN 未校验。实测 USED_WARN=abc 时 `[ "$U" -ge "abc" ]` 报
#        integer expression expected 并返回非 0，if 走 else 分支 → 脚本 exit 0，
#        【容量告警被静默关闭】。现与 KEEP_DAYS 同等强度校验。
# ==============================================================================
# v1.1.6 修订：
#   [-] 数值参数校验逻辑已抽入 kb_lib.sh 的 kb_need_int()，本脚本保持内联实现
#       （它是唯一不 source kb_lib 的脚本 —— 以 set -Eeuo pipefail 自实现
#        fail-closed，避免删除类脚本依赖外部文件）。
#
# v1.1.7 修订：
#   [P2] ALLOW_PREFIX 只覆盖 /data/kingbase/log。三容量域方案一旦把日志改到
#        备份卷（建议版方案），本脚本会以「白名单之外」直接拒绝执行，表现为
#        日志保留策略【静默停止】。现在白名单同时覆盖两版存储方案的日志路径，
#        仍然固定在脚本内、不接受环境变量覆盖。
#        ⚠️ 白名单只是安全边界；实际清理哪个目录由【命令行参数 / cron 行】决定，
#           存储方案落地时必须同步改 cron 里的路径。
# ==============================================================================
set -Eeuo pipefail
trap 'echo "★ 第 $LINENO 行失败，已中止" >&2; exit 1' ERR

LOGDIR_IN=${1:-/data/kingbase/log}
KEEP_DAYS=${KEEP_DAYS:-30}
USED_WARN=${USED_WARN:-80}
# ★ 白名单固定在脚本内，【不接受环境变量覆盖】——这是删除脚本的安全边界
# ★ 覆盖两版存储方案：现场版 /data/kingbase/log；建议版（日志并入备份卷）
#   /data/kingbase/backup/log。另含数据库自身 log 目录。
ALLOW_PREFIX="/data/kingbase/log /data/kingbase/backup/log /home/kingbase/cluster/kingbase/log"

# ---- 1. KEEP_DAYS 硬校验（正整数 + 合理区间）----
case "$KEEP_DAYS" in
  ''|*[!0-9]*) echo "★ ERROR: KEEP_DAYS 必须为正整数，当前=[$KEEP_DAYS]" >&2; exit 1 ;;
esac
case "$USED_WARN" in
  ''|*[!0-9]*) echo "★ ERROR: USED_WARN 必须为正整数，当前=[$USED_WARN]" >&2; exit 1 ;;
esac
if [ "$USED_WARN" -lt 50 ] || [ "$USED_WARN" -gt 99 ]; then
    echo "★ ERROR: USED_WARN=$USED_WARN 超出允许区间 [50,99]" >&2; exit 1
fi
if [ "$KEEP_DAYS" -lt 7 ] || [ "$KEEP_DAYS" -gt 3650 ]; then
    echo "★ ERROR: KEEP_DAYS=$KEEP_DAYS 超出允许区间 [7,3650]" >&2; exit 1
fi

# ---- 2. 目录校验 ----
LOGDIR=$(realpath -e "$LOGDIR_IN" 2>/dev/null) || { echo "★ ERROR: 目录不存在：$LOGDIR_IN" >&2; exit 1; }
[ -d "$LOGDIR" ] || { echo "★ ERROR: 不是目录：$LOGDIR" >&2; exit 1; }

ok=0
for p in $ALLOW_PREFIX; do case "$LOGDIR" in "$p"|"$p"/*) ok=1;; esac; done
[ "$ok" = 1 ] || { echo "★ ERROR: 拒绝在白名单之外执行删除：$LOGDIR" >&2
                   echo "         白名单：$ALLOW_PREFIX" >&2; exit 1; }
case "$LOGDIR" in /|/home|/data|/var|/etc|/usr|/boot) echo "★ ERROR: 拒绝危险目录：$LOGDIR" >&2; exit 1;; esac

# ---- 3. 清理（★ 不用 tee /dev/stderr，避免截断 cron 日志）----
TMP=$(mktemp /tmp/kb_log_cleanup.XXXXXX)
trap 'rm -f "$TMP"' EXIT

echo "清理 $LOGDIR 中 mtime 超过 ${KEEP_DAYS} 天的日志（.log 与 .csv 都覆盖）"
BEFORE=$(du -sh "$LOGDIR" | awk '{print $1}')
find "$LOGDIR" -maxdepth 1 -type f \( -name '*.log' -o -name '*.csv' \) \
     -mtime +"$KEEP_DAYS" -print -delete > "$TMP"
N=$(wc -l < "$TMP")
[ "$N" -gt 0 ] && { echo "已删除文件："; sed 's/^/  /' "$TMP"; }
AFTER=$(du -sh "$LOGDIR" | awk '{print $1}')
echo "共删除 $N 个文件；清理前 $BEFORE → 清理后 $AFTER"

# ---- 4. 容量告警 ----
U=$(df -P "$LOGDIR" | awk 'NR==2{gsub(/%/,"",$5);print $5}')
if [ -z "${U:-}" ]; then echo "★ ERROR: 无法获取 $LOGDIR 的空间使用率" >&2; exit 1; fi
if [ "$U" -ge "$USED_WARN" ]; then
    echo "★ 日志所在文件系统已用 ${U}% ≥ ${USED_WARN}%，需关注" >&2; exit 1
fi
echo "日志文件系统已用 ${U}%"
exit 0
