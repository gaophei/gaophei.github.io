#!/usr/bin/env bash
# ==============================================================================
# kb_lib.sh v1.1.7 —— 巡检脚本公用库
#
# ★ 本文件是【库】，必须被 source，不可直接执行。
#   v1.1.5 增加自我保护：现场曾出现 `./kb_lib.sh` 被直接运行（无任何输出，
#   看起来像"跑成功了"）。
#
# ★ 抽出公用函数的目的：避免各脚本各写一套判定逻辑而重新退回 fail-open。
#   本系列已发生过一次：主采集脚本建立了四态 fail-closed，新拆出的专项脚本
#   从零写起时又回到「只有 FAIL 改变退出码」。
# ==============================================================================

# ---- 防直接执行 ----
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    echo "★ kb_lib.sh 是公用库，请用 source 引入，不要直接执行。" >&2
    echo "  正确用法：在脚本中  . \"\$(dirname \"\$0\")/kb_lib.sh\"" >&2
    exit 1
fi

KB_LIB_VERSION="1.1.7"
KB_P=0; KB_F=0; KB_W=0; KB_E=0

# say <PASS|FAIL|WARN|ERROR> <消息>
# ★ FAIL 与 ERROR 同样阻断 —— 「取不到证据」不等于「通过」
say(){
  case "$1" in
    PASS)  KB_P=$((KB_P+1));;
    FAIL)  KB_F=$((KB_F+1));;
    WARN)  KB_W=$((KB_W+1));;
    ERROR) KB_E=$((KB_E+1));;
  esac
  printf '[%-5s] %s\n' "$1" "$2"
  return 0
}

# kb_summary <标题> —— 打印汇总并返回退出码（FAIL 或 ERROR 任一非零即 1）
kb_summary(){
  echo "-------------------------------------------------------------"
  printf '%s： PASS=%d  FAIL=%d  WARN=%d  ERROR=%d\n' "${1:-合计}" "$KB_P" "$KB_F" "$KB_W" "$KB_E"
  if [ "$KB_F" -gt 0 ] || [ "$KB_E" -gt 0 ]; then
      echo "结论：★ 不通过（FAIL 或 ERROR 非零；ERROR 表示证据缺失，同样阻断）"
      return 1
  elif [ "$KB_W" -gt 0 ]; then
      echo "结论：无 FAIL/ERROR，但有 $KB_W 项需人工确认"
      return 0
  fi
  echo "结论：全部通过"
  return 0
}

# kb_paused <repmgr路径> —— 从表头定位 Paused 列，回显 "pcol total yes no"
# ★ 不硬编码列号：真实表头为 ID|Name|Role|Status|Upstream|repmgrd|PID|Paused?|...
#   Paused? 是第 8 列，早期版本误取 $7（PID 列），使该判定必然 PASS。
kb_paused(){
  local RS
  RS=$("$1" service status 2>/dev/null) || return 1
  [ -n "$RS" ] || return 1
  printf '%s\n' "$RS" | awk -F'|' '
    pc==0 { for(i=1;i<=NF;i++){h=tolower($i);gsub(/[ \t?]/,"",h); if(h=="paused"){pc=i;break}} }
    ($1+0)>0 && NF>2 { n++
      if(pc>0&&pc<=NF){v=tolower($pc);gsub(/[ \t]/,"",v); if(v=="yes")y++; else if(v=="no")o++} }
    END{ printf "%d %d %d %d", pc+0, n+0, y+0, o+0 }'
}

# kb_ping_ok <ip> —— 复现 repmgr 的探测方式，★ 判据是【收到回包数 > 0】而非退出码
#   现场实证：`ping -c 3 -w 2` 在默认 1s 包间隔下只能发出 2 个包
#   （t=0、t=1，t=2 即 deadline），count 永远凑不满 3 →【退出码恒为 1】。
#   iputils 规则：同时指定 count 与 deadline 时，deadline 前收到的包少于 count
#   也返回 1。故用退出码判定会把完全正常的网络判成"不可达"。
kb_ping_ok(){
  # ★ v1.1.6：固定 LC_ALL=C —— 本函数靠解析英文 "received" 判定，
  #   现场 locale 变化会使 ping 输出本地化，导致文本匹配失效。
  LC_ALL=C ping -c "${KB_PING_C:-3}" -w "${KB_PING_W:-2}" "$1" 2>/dev/null \
    | grep -qE '[1-9][0-9]* *(packets )?received'
}

# kb_role <数据目录> —— 判定本节点角色，回显 primary / standby
#   ★ 不解析 `repmgr node status` 的文本：其字段是【缩进】的（\tRole: primary），
#     用 /^Role/ 锚定行首匹配不到，现场两节点均因此报 ERROR。
#     standby.signal 是文件事实，稳定得多。
kb_role(){
  [ -d "$1" ] || return 1
  if [ -f "$1/standby.signal" ]; then echo standby; else echo primary; fi
}

# kb_need_int <变量名> <值> <min> <max> —— 数值参数入口校验
#   ★ v1.1.6：不做校验时，`[ "$U" -ge "$X" ]` 遇非数字会报 integer expression
#     expected 并返回非 0，if 走 else 分支，**该条判据被静默绕开**。
kb_need_int(){
  local name=$1 val=$2 lo=$3 hi=$4
  case "$val" in
    ''|*[!0-9]*) echo "★ ERROR: $name 必须为正整数，当前=[$val]" >&2; return 1 ;;
  esac
  if [ "$val" -lt "$lo" ] || [ "$val" -gt "$hi" ]; then
      echo "★ ERROR: $name=$val 超出允许区间 [$lo,$hi]" >&2; return 1
  fi
  return 0
}
