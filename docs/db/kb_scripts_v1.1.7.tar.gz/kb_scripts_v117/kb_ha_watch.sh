#!/usr/bin/env bash
# ==============================================================================
# HA 静默降级巡检  kb_ha_watch.sh  v1.1.7
#
# 用途：查那些【数据库端口通、监控全绿，但 HA 已失效】的状态
# 用法：bash kb_ha_watch.sh          （★ kingbase 身份，复现 HA 组件的实际权限）
# 退出码：0 = 无 FAIL/ERROR   1 = 存在 FAIL 或 ERROR
#
# v1.1 修订：
#   [P0] v1.0 的 say() 只在 FAIL 时置位 —— repmgr 命令失败、Paused 无法解析、
#        trusted_servers 无法解析全是 ERROR，却仍输出「结论：HA 状态正常 / exit 0」。
#        对一个名为「静默降级巡检」的脚本，这本身就是静默降级。改用四态判定。
#   [P0] VIP 判据：① role 查询失败会静默跳过整段检查；② 只要机器上存在任意
#        secondary 地址就 PASS，未核对实际 VIP。现改为精确匹配 repmgr.conf 的
#        virtual_ip，并同时防「主库无 VIP / 备库误挂 VIP / 双节点都有 VIP」。
#   [P1] 以 kingbase 身份运行时不再 sudo -u kingbase（kingbase 通常无 sudo 权限，
#        会得到假的 trusted_servers 不可达）。
#   [-]  Paused 解析改用 kb_lib.sh 的公用函数，避免各脚本各写一套而退回裸 grep。
#
# v1.1.1 修订：
#   [P0] VIP 检查仍有 fail-open：`ip ... | grep -q` 把「ip 执行失败」与「确实
#        没有 VIP」合并为 HAS_VIP=0，备库分支会输出 PASS「备库上无 VIP（正确）」。
#        现改为先捕获 ip 输出并判断其返回值，取证失败一律 ERROR。
#
# v1.1.2 修订：
#   [P0] 进程存活判定用 `pgrep -f`（匹配完整命令行），会被无关进程骗过 ——
#        实测 `exec -a "tail -f /var/log/kbha.log" sleep` 即可让 `pgrep -f kbha`
#        命中，而真正的 kbha 已死。对「静默降级巡检」这是核心判据假 PASS。
#        改为 `pgrep -x`（精确进程名）+ 校验 /proc/<pid>/exe 指向批准的可执行文件。
#   [P1] ping 能力判定原为「有 cap_net_raw 或 setuid，否则 FAIL」，遗漏了
#        net.ipv4.ping_group_range 覆盖 kingbase gid 这条合法路径；且真正决定
#        HA 能否工作的是下一步的实际 ping 结果。改为三条任一成立即 PASS，
#        全不成立时降为 WARN 并由实际探测结果定论。
#
# v1.1.3 修订：
#   [P1] 进程校验只取第一个 PID —— 若同时存在合法与异常的同名进程，只要第一个
#        合法就 PASS，第二个被完全忽略。改为断言 PID 数量恰好为 1，多个即 FAIL。
#   [P1] `/proc/<pid>/exe` 已是 realpath，而期望值用的是原始字符串。若
#        $KB_HOME 本身是指向 PS062 版本化目录的软链，同一个文件也会被判 FAIL。
#        改为两侧都 readlink -f 后比较，并输出两个路径便于现场留证。
#
# v1.1.5 修订（两项均由现场实跑暴露，且都是【假报警】）：
#   [P0] trusted_servers 用 ping 的【退出码】判定 —— 现场实证为误报：
#        `ping -c 3 -w 2` 在默认 1s 包间隔下只能发出 2 个包（t=0、t=1，
#        t=2 即 deadline），count 永远凑不满 3 → 退出码恒为 1。两节点手工
#        ping 明明是 `2 received, 0% packet loss`，脚本却报"全部不可达"。
#        改用 kb_lib.sh 的 kb_ping_ok()：判据为【收到回包数 > 0】。
#        ⚠️ 同时说明：hamgr.log 实测显示 repmgrd 正常状态下【不做】该探测，
#           只在察觉连接异常时才触发，故本项是"故障时可用性"的预检，
#           不是"当前正在失败"的告警。
#   [P0] 角色解析用 `repmgr node status | awk '/^Role/'`，而该命令输出的字段
#        是【缩进】的（\tRole: primary），行首锚定匹配不到 —— 现场两节点均报
#        "无法查询本节点角色"。改用 kb_lib.sh 的 kb_role()：以 standby.signal
#        文件为事实依据，不依赖任何输出格式。
#   [补回] VIP 精确匹配（net_device + 掩码）—— 该项在 v1.1.4 定稿但未落盘，
#        v1.1.5 基于 v1.1.3 修改时被覆盖丢失，现补回。
#        仅做「本机任意网卡上有无该地址」的字符串匹配是不够的：VIP 挂错网卡
#        或掩码不符时业务同样不可达，却会被判 PASS。
#
# v1.1.6 修订：
#   [P1] trusted_servers 判定的措辞对 repmgr 后续行为下结论过强
#        （原写「repmgrd 将判网络故障」）。README 已承认 repmgr 内部实际使用的
#        命令与判据【仍未查证】，且 hamgr.log 实测显示正常状态下根本不做该探测。
#        故本项只能定位为「**等价预检**」，实际 HA 行为以 B/C 类演练及
#        hamgr/kbha 日志为准。
#   [-]  ping 判据沿用 kb_lib.sh 的 kb_ping_ok()，v1.1.6 起其内部固定 LC_ALL=C。
#
# v1.1.7 修订：
#   [-] 本脚本【逻辑无变更】，仅随包统一版本号。v1.1.7 的实质修订集中在
#       kb_backup_check.sh（补 -w）与 kb_offcluster_copy.sh（字节比对 / SIGPIPE）。
# ==============================================================================
set -u
SDIR=$(dirname "$(readlink -f "$0")")
. "$SDIR/kb_lib.sh" || { echo "缺少 kb_lib.sh"; exit 1; }

KB_HOME=${KB_HOME:-/home/kingbase/cluster/kingbase}
KB_DATA=${KB_DATA:-$KB_HOME/data}
REPMGR_CONF=${REPMGR_CONF:-$KB_HOME/etc/repmgr.conf}
REPMGR=$KB_HOME/bin/repmgr

echo "===== HA 静默降级巡检 v1.1.7  $(date '+%F %T')  身份=$(id -un) ====="

# ★ 以 kingbase 运行时直接调用；以 root 运行时才降权
#   kb_ping_ok 内部调用 ping；以 root 运行时需降权到 kingbase
if [ "$(id -un)" = "kingbase" ]; then ping(){ command /bin/ping "$@"; }
else                                  ping(){ sudo -u kingbase /bin/ping "$@"; }; fi

# ---- 1. repmgrd / kbha 进程存活（★ 精确进程名 + 可执行文件校验）----
for p in repmgrd kbha; do
    # ★ if 上下文取返回码（本脚本无 ERR trap，但统一写法避免日后加 trap 时踩坑）
    if PIDS=$(pgrep -x "$p" 2>/dev/null); then rc=0; else rc=$?; fi
    NPID=$(printf '%s' "${PIDS:-}" | grep -c . || true)
    # ★ 期望值也要 readlink -f：$KB_HOME 可能是指向 PS062 版本化目录的软链
    EXPECTED=$(readlink -f "$KB_HOME/bin/$p" 2>/dev/null || true)

    if [ "$rc" -gt 1 ]; then
        say ERROR "pgrep -x $p 执行异常(rc=$rc) —— 无法判定 $p 状态"
    elif [ "$NPID" -eq 0 ]; then
        say FAIL "★ $p 进程不存在 —— HA 能力已丧失"
    elif [ "$NPID" -gt 1 ]; then
        # ★ HA daemon 正常应只有一个实例；多个通常意味着残留或异常拉起
        say FAIL "★ 发现 $NPID 个 $p 进程(pid: $(printf '%s' "$PIDS" | tr '\n' ' '))—— 应恰好 1 个"
    else
        EXE=$(readlink -f "/proc/$PIDS/exe" 2>/dev/null || true)
        if [ -z "$EXE" ]; then
            say WARN "$p 进程存在(pid=$PIDS)，但无法读取 /proc/$PIDS/exe 校验其身份"
        elif [ -z "$EXPECTED" ]; then
            say ERROR "无法解析批准路径 $KB_HOME/bin/$p 的真实路径"
        elif [ "$EXE" = "$EXPECTED" ]; then
            say PASS "$p 进程存活(pid=$PIDS)，可执行文件校验通过"
        else
            say FAIL "★ 名为 $p 的进程(pid=$PIDS)指向 $EXE，非批准的 $EXPECTED"
        fi
        # 首次现场运行请留存以下两行证据（软链场景下二者应一致）
        echo "           exe=$EXE"
        echo "           批准=$EXPECTED"
    fi
done

# ---- 2. Paused 状态（公用函数，从表头定位列号）----
if OUT=$(kb_paused "$REPMGR"); then
    read -r pcol nn nyes nno <<<"$OUT"
    if   [ "${pcol:-0}" -eq 0 ];        then say ERROR "repmgr 输出表头未找到 Paused 列"
    elif [ "${nn:-0}"  -eq 0 ];         then say ERROR "repmgr 输出未解析出节点行"
    elif [ $((nyes+nno)) -ne "$nn" ];   then say ERROR "Paused 列存在无法识别的值（yes=$nyes no=$nno 行=$nn）"
    elif [ "$nyes" -gt 0 ];             then say FAIL  "★ $nyes/$nn 节点 Paused=yes —— 自动 failover 被禁用"
    else say PASS "$nn 个节点全部【明确】Paused=no"; fi
else say ERROR "repmgr service status 执行失败 —— 无法判定 Paused 状态"; fi

# ---- 3. ping 能力（三条合法路径任一成立即可；否则由实际探测定论）----
PING_CAP_OK=0
if getcap /bin/ping 2>/dev/null | grep -q cap_net_raw; then
    say PASS "/bin/ping 具备 cap_net_raw"; PING_CAP_OK=1
elif [ -u /bin/ping ]; then
    say PASS "/bin/ping 具备 setuid"; PING_CAP_OK=1
else
    # 第三条路径：net.ipv4.ping_group_range 覆盖 kingbase 的 gid
    GR=$(sysctl -n net.ipv4.ping_group_range 2>/dev/null || true)
    GID=$(id -g kingbase 2>/dev/null || true)
    LO=$(printf '%s' "$GR" | awk '{print $1}'); HI=$(printf '%s' "$GR" | awk '{print $2}')
    if [ -n "${GID:-}" ] && [ -n "${LO:-}" ] && [ -n "${HI:-}" ] \
       && [ "$LO" -le "$HI" ] 2>/dev/null && [ "$GID" -ge "$LO" ] && [ "$GID" -le "$HI" ] 2>/dev/null; then
        say PASS "ping_group_range=[$LO,$HI] 覆盖 kingbase gid=$GID"; PING_CAP_OK=1
    else
        say WARN "/bin/ping 无 cap_net_raw / setuid，且 ping_group_range 未覆盖 kingbase —— 以下方实际探测结果为准"
    fi
fi

# ---- 4. trusted_servers 可达性（复现 repmgr 的 ping -c3 -w2）----
TS=$(grep -oP "^\s*trusted_servers\s*=\s*['\"]?\K[^'\"]+" "$REPMGR_CONF" 2>/dev/null || true)
if [ -z "${TS:-}" ]; then
    say ERROR "无法从 $REPMGR_CONF 解析 trusted_servers"
else
    bad=0; tot=0
    for ip in $(printf '%s' "$TS" | tr ',' ' '); do
        tot=$((tot+1))
        kb_ping_ok "$ip" || bad=$((bad+1))   # ★ 判据是收包数>0，非退出码
    done
    ok=$((tot-bad))
    if   [ "$tot" -eq 0 ]; then say ERROR "trusted_servers 解析结果为空"
    elif [ "$ok"  -eq 0 ]; then say FAIL  "★ trusted_servers 等价预检全部失败（$tot 个均不可达）—— 实际 HA 判定与后续行为以 B/C 类演练及 hamgr/kbha 日志为准"
    elif [ "$bad" -gt 0 ]; then say WARN  "trusted_servers 等价预检 $ok/$tot 可达（repmgr 判定为任一可达即正常），冗余度下降，须查明失败目标"
    else say PASS "trusted_servers 等价预检 $tot/$tot 全部可达"; fi
fi

# ---- 5. ★ VIP 精确判定：主库应有、备库应无 ----
VIP=$(grep -oP "^\s*virtual_ip\s*=\s*['\"]?\K[^'\"]+" "$REPMGR_CONF" 2>/dev/null || true)
NETDEV=$(grep -oP "^\s*net_device\s*=\s*['\"]?\K[^'\"]+" "$REPMGR_CONF" 2>/dev/null || true)
VIP_ADDR=${VIP%%/*}
VIP_PFX=${VIP#*/}
[ "$VIP_PFX" = "$VIP" ] && VIP_PFX=""
if [ -z "${VIP_ADDR:-}" ]; then
    say ERROR "无法从 $REPMGR_CONF 解析 virtual_ip"
elif [ -z "${NETDEV:-}" ]; then
    say ERROR "无法从 $REPMGR_CONF 解析 net_device —— 无法核对 VIP 是否挂在正确网卡"
else
    # ★ 必须先确认 ip 执行成功，才能把「无匹配」解释成「无 VIP」
    if ! IPOUT=$(ip -4 -o addr show 2>/dev/null); then
        say ERROR "ip addr 执行失败 —— 无法判定 VIP $VIP_ADDR 的归属"
        HAS_VIP=-1
    else
        # ★ 精确匹配 addr/prefix 且在配置指定的网卡上
        WANT=$VIP_ADDR${VIP_PFX:+/$VIP_PFX}
        if printf '%s\n' "$IPOUT" | awk -v d="$NETDEV" -v w="$WANT" '$2==d && $4==w{f=1} END{exit !f}'; then
            HAS_VIP=1
        elif printf '%s\n' "$IPOUT" | grep -qw "$VIP_ADDR"; then
            HAS_VIP=2   # 地址在，但网卡或掩码不符
        else HAS_VIP=0; fi
    fi

    if [ "$HAS_VIP" = "-1" ]; then
        : # 已在上面报 ERROR，不再做角色判定
    elif ROLE=$(kb_role "$KB_DATA") && [ -n "${ROLE:-}" ]; then
        case "$ROLE" in
          *primary*)
            case "$HAS_VIP" in
              1) say PASS "主库上 VIP ${VIP_ADDR}/${VIP_PFX:-?} 已挂载于 $NETDEV" ;;
              2) say FAIL "★ VIP $VIP_ADDR 存在，但不在 $NETDEV 上或掩码与 $VIP 不符 —— 业务同样可能不可达"
                 printf '%s\n' "$IPOUT" | grep -w "$VIP_ADDR" | sed 's/^/           /' ;;
              *) say FAIL "★ 本节点为主库但 VIP $VIP_ADDR 未挂载 —— 业务不可达" ;;
            esac ;;
          *standby*)
            case "$HAS_VIP" in
              0) say PASS "备库上无 VIP（正确）" ;;
              *) say FAIL "★ 本节点为备库却挂载了 VIP $VIP_ADDR —— 疑似双主 / VIP 异常" ;;
            esac ;;
          *) say ERROR "无法识别节点角色：$ROLE" ;;
        esac
    else
        # role 查询失败时不静默跳过
        say ERROR "无法判定本节点角色（数据目录 $KB_DATA 不存在？）—— VIP $VIP_ADDR 当前 $([ "$HAS_VIP" = 1 ] && echo 已挂载 || echo 未挂载)"
    fi
fi

echo
kb_summary "HA 静默降级巡检"
