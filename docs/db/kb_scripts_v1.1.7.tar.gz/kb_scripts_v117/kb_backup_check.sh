#!/usr/bin/env bash
# ==============================================================================
# KingbaseES 备份健康巡检  kb_backup_check.sh  v1.1.7
#
# 用途：验证【备份产物是否真的生成且完整】，而不是只看 cron 行是否存在。
# 用法：bash kb_backup_check.sh          （kingbase 身份）
# 退出码：0 = 无 FAIL/ERROR   1 = 存在 FAIL 或 ERROR
#
# v1.1.5 修订（三项均由现场实跑暴露）：
#   [P0] 逻辑备份只取【全树最新一个文件】。现场 dump/ 下每库一个子目录，
#        dataassets 正常就会把其他库的缺失完全盖住 —— 永远发现不了"某个库
#        从来没被备过"。现改为：**从 sys_database 查出应备份库清单，逐库核对**。
#   [P0] 每次备份同时产出 `<db>_<ts>.tar.gz`（数据）与 `backup_log_<db>_<ts>.tar.gz`
#        （日志归档，约 185B）。按 mtime 取最新恰好取到日志包 → 误判 FAIL。
#        现明确排除 `backup_log_*`。
#   [P0] 绝对字节阈值（MIN_DUMP_BYTES）在数据增长期不成立 —— 现场 9/3 空库时的
#        合法备份仅 618B，改对匹配模式后仍会被判 FAIL。改用
#        **gzip -t 完整性校验 + 相对趋势**：完整性与库大小无关，才是正确代理指标。
#
# v1.1.7 修订：
#   [P1] **`kq()` 仍未带 `-w`**。v1.1.6 的 README 与 backup8.conf 都已更正
#        「`-w`(--no-password) 与 `-W`(--password) 相反，批处理需要的是 `-w`」，
#        并宣称「凭据三处错误全部修完」，但本脚本漏改，还保留着 v1.1.5 的
#        错误推理注释 —— **文档声称的修复与代码实际状态不一致**。
#        后果：缺少 ~/.kbpass 时 ksql 会尝试交互取口令，cron 下无 tty，
#        失败原因又被 `2>/dev/null` 吞掉，最终只呈现为一句没有原因的
#        「数据库连接失败」，现场无法区分「口令缺失 / 服务不通 / 认证失败」。
#   [P1] 连通性判定改用保留 stderr 的探针，ERROR 消息带出首行原因。
#
# 说明：EXCLUDE_DBS 默认自动从 backup8.conf 解析，与备份脚本保持同源。
# ==============================================================================
set -u
SDIR=$(dirname "$(readlink -f "$0")")
. "$SDIR/kb_lib.sh" || { echo "缺少 kb_lib.sh"; exit 1; }

KB_HOME=${KB_HOME:-/home/kingbase/cluster/kingbase}
REPO=${REPO:-/data/kingbase/backup/rman}
DUMP=${DUMP:-/data/kingbase/backup/dump}
BACKUP8_CONF=${BACKUP8_CONF:-/home/kingbase/backup_script/backup8.conf}
LOGICAL_LOG=${LOGICAL_LOG:-/home/kingbase/backup_script/logical_backup.log}
DB_HOST=${DB_HOST:-127.0.0.1}
DB_PORT=${DB_PORT:-54321}
DB_USER=${DB_USER:-system}
DB_NAME=${DB_NAME:-test}
MAX_FULL_AGE_H=${MAX_FULL_AGE_H:-192}
MAX_INCR_AGE_H=${MAX_INCR_AGE_H:-30}
MAX_DUMP_AGE_H=${MAX_DUMP_AGE_H:-30}
SHRINK_PCT=${SHRINK_PCT:-50}          # 相对上一次骤降超过该百分比即告警
REPO_USED_WARN=${REPO_USED_WARN:-80}

# ★ v1.1.7：统一连接参数，显式带 -h 与 -w。
#   -w = --no-password：禁止交互提示，无凭据时【立即失败】—— 无人值守正需要。
#   -W = --password   ：强制提示输入密码 —— 现场注释否定的是这一个。
#   .kbpass 首列按【实际连接使用的 host】匹配，不带 -h 时匹配目标是 localhost。
KSQL_OPTS=(-h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -w)
kq(){ "$KB_HOME/bin/ksql" "${KSQL_OPTS[@]}" -Atc "$1" 2>/dev/null; }
# ★ 仅用于第 0 项连通性判定：**保留 stderr**，使 ERROR 能带出失败原因。
#   其余查询仍丢弃 stderr —— 它们的"无输出"已由各自的 ERROR 分支兜底。
kq_probe(){ "$KB_HOME/bin/ksql" "${KSQL_OPTS[@]}" -Atc "SELECT 1" 2>"$KSQL_ERR"; }

# ★ v1.1.6：数值参数统一入口校验 —— 不校验时非法值会让对应判据被静默绕开
for kv in "MAX_FULL_AGE_H:$MAX_FULL_AGE_H:1:8760" "MAX_INCR_AGE_H:$MAX_INCR_AGE_H:1:8760" \
          "MAX_DUMP_AGE_H:$MAX_DUMP_AGE_H:1:8760" "SHRINK_PCT:$SHRINK_PCT:1:99" \
          "REPO_USED_WARN:$REPO_USED_WARN:50:99" "DB_PORT:$DB_PORT:1:65535"; do
    IFS=: read -r _n _v _lo _hi <<<"$kv"
    kb_need_int "$_n" "$_v" "$_lo" "$_hi" || exit 1
done

RMAN_OUT=$(mktemp /tmp/kb_rman.info.XXXXXX)
GZ_ERR=$(mktemp /tmp/kb_gz.err.XXXXXX)
KSQL_ERR=$(mktemp /tmp/kb_ksql.err.XXXXXX)
trap 'rm -f "$RMAN_OUT" "$GZ_ERR" "$KSQL_ERR"' EXIT

echo "===== KingbaseES 备份健康巡检 v1.1.7  $(date '+%F %T') ====="
echo "  repo=$REPO"
echo "  dump=$DUMP"
echo

# ---- 0. 数据库连通性 ----
if ! kq_probe >/dev/null; then
    # ★ 带出首行原因：口令文件缺失 / 服务未启动 / 认证失败在现场是三种处置
    RSN=$(head -1 "$KSQL_ERR" 2>/dev/null | tr -d '\r')
    say ERROR "数据库连接失败（$DB_HOST:$DB_PORT）${RSN:+：$RSN}"; DB_OK=0
else
    say PASS "数据库连接正常（$DB_HOST:$DB_PORT）"; DB_OK=1
fi

# ---- 1. 归档 ----
if [ "$DB_OK" = 1 ]; then
    A=$(kq "SELECT CASE WHEN last_failed_time IS NULL OR last_archived_time > last_failed_time
                   THEN 'OK|'||COALESCE(last_archived_time::text,'-')
                   ELSE 'BAD|'||last_failed_time END FROM sys_stat_archiver")
    if   [ -z "$A" ];         then say ERROR "无法查询 sys_stat_archiver"
    elif [ "${A%%|*}" = OK ]; then say PASS  "归档无未恢复失败，最近成功 ${A#*|}"
    else say FAIL "归档异常：最近一次失败(${A#*|})晚于最近一次成功"; fi
else say ERROR "跳过归档检查（数据库不可连）"; fi

# ---- 2. 复制槽 ----
if [ "$DB_OK" = 1 ]; then
    R=$(kq "SELECT COALESCE(max(round(sys_wal_lsn_diff(sys_current_wal_lsn(),restart_lsn)/1024/1024)),-1)
            FROM sys_replication_slots WHERE restart_lsn IS NOT NULL")
    if   [ -z "$R" ];     then say ERROR "无法查询 sys_replication_slots"
    elif [ "$R" = "-1" ]; then say WARN  "本节点无复制槽（备库侧正常；主库侧须确认）"
    elif [ "$R" -lt 1024 ] 2>/dev/null; then say PASS "复制槽最大滞留 ${R}MB"
    else say FAIL "复制槽滞留 ${R}MB —— 本版本无 max_slot_wal_keep_size 保护"; fi
else say ERROR "跳过复制槽检查（数据库不可连）"; fi

# ---- 3. 物理备份（sys_rman info 解析，取最大时间）----
RMAN_CONF="$REPO/sys_rman.conf"
if [ ! -r "$RMAN_CONF" ]; then
    say ERROR "sys_rman.conf 不可读：$RMAN_CONF"
elif ! "$KB_HOME/bin/sys_rman" --config="$RMAN_CONF" --stanza=kingbase info > "$RMAN_OUT" 2>&1; then
    say FAIL "sys_rman info 执行失败：$(head -2 "$RMAN_OUT" | tr '\n' ' ')"
else
    say PASS "sys_rman info 可读"
    NOW=$(date +%s)
    for TY in full incr; do
        TS=$(awk -v ty="$TY" '
              $0 ~ ty" backup:" {inb=1; next}
              inb && /timestamp start\/stop:/ {
                  sub(/.*timestamp start\/stop: /,""); sub(/ \/.*/,""); print; inb=0 }' "$RMAN_OUT" \
             | sort | tail -1)
        LIM=$([ "$TY" = full ] && echo "$MAX_FULL_AGE_H" || echo "$MAX_INCR_AGE_H")
        if [ -z "$TS" ]; then
            say FAIL "★ sys_rman info 中无 ${TY} backup 记录"
        else
            E=$(date -d "$TS" +%s 2>/dev/null) || E=""
            if [ -z "$E" ]; then say ERROR "无法解析 ${TY} 备份时间戳：$TS"
            else
                AGE=$(( (NOW-E)/3600 ))
                [ "$AGE" -le "$LIM" ] && say PASS "${TY}备最近成功于 ${TS}（${AGE}h 前，阈值 ${LIM}h）" \
                                      || say FAIL "★ ${TY}备最近成功于 ${TS}（${AGE}h 前 > 阈值 ${LIM}h）"
            fi
        fi
    done
fi

# ==============================================================================
# 4. ★ 逻辑备份：按库逐个核对（v1.1.5 核心修订）
# ==============================================================================
echo
echo "---- 逻辑备份（按库核对）----"

# 4a 取应备份库清单：优先从 backup8.conf 解析排除规则，保持与备份脚本同源
EXC_RAW=""
if [ -r "$BACKUP8_CONF" ]; then
    EXC_RAW=$(grep -o "not in ([^)]*)" "$BACKUP8_CONF" 2>/dev/null | head -1 \
              | sed "s/not in (//; s/)//; s/'//g; s/ //g")
fi
if [ -n "$EXC_RAW" ]; then
    say PASS "排除规则取自 $BACKUP8_CONF：$EXC_RAW"
else
    EXC_RAW=${EXCLUDE_DBS:-kingbase,template1,template0,security}
    say WARN "无法从 backup8.conf 解析排除规则，使用默认值：$EXC_RAW（★ 须人工确认与备份脚本一致）"
fi

if [ "$DB_OK" != 1 ]; then
    say ERROR "跳过逐库核对（数据库不可连）"
else
    EXC_SQL=$(printf "'%s'," $(printf '%s' "$EXC_RAW" | tr ',' ' ') | sed 's/,$//')
    DBS=$(kq "SELECT datname FROM sys_database WHERE datname NOT IN ($EXC_SQL) ORDER BY 1")
    if [ -z "$DBS" ]; then
        say ERROR "无法取得应备份库清单"
    else
        NDB=$(printf '%s\n' "$DBS" | grep -c .)
        say PASS "应备份库共 $NDB 个：$(printf '%s' "$DBS" | tr '\n' ' ')"
        NOW=$(date +%s)
        for db in $DBS; do
            D="$DUMP/$db"
            if [ ! -d "$D" ]; then
                # ★ 新建库尚未到备份时点属正常，判 WARN 转人工，不直接 FAIL
                say WARN "库 [$db] 无 dump 目录 —— 若为新建库属正常，须人工确认建库时间晚于最近一次备份"
                continue
            fi
            # ★ 必须排除 backup_log_*（日志归档约 185B，mtime 比数据包更晚）
            NEW=$(find "$D" -maxdepth 1 -type f -name '*.tar.gz' ! -name 'backup_log_*' \
                       -printf '%T@ %s %p\n' 2>/dev/null | sort -nr | head -1)
            if [ -z "$NEW" ]; then
                say FAIL "★ 库 [$db] 目录存在但无数据备份产物（已排除 backup_log_*）"
                continue
            fi
            EP=$(printf '%s' "$NEW" | awk '{print $1}'); EP=${EP%.*}
            SZ=$(printf '%s' "$NEW" | awk '{print $2}')
            FP=$(printf '%s' "$NEW" | cut -d' ' -f3-)
            AGE=$(( (NOW-EP)/3600 ))
            BN=$(basename "$FP")

            if [ "$AGE" -gt "$MAX_DUMP_AGE_H" ]; then
                say FAIL "★ 库 [$db] 最新备份 $BN 已 ${AGE}h（> ${MAX_DUMP_AGE_H}h）"
                continue
            fi
            # ★ 完整性优先于大小：gzip -t 与库大小无关，空库的小备份同样能通过
            if ! gzip -t "$FP" 2>"$GZ_ERR"; then
                say FAIL "★ 库 [$db] 最新备份 $BN 完整性校验失败：$(head -1 "$GZ_ERR")"
                continue
            fi
            # 相对趋势：与上一次比较，骤降超过阈值才告警（不设绝对字节下限）
            PREV=$(find "$D" -maxdepth 1 -type f -name '*.tar.gz' ! -name 'backup_log_*' \
                        -printf '%T@ %s\n' 2>/dev/null | sort -nr | sed -n 2p | awk '{print $2}')
            if [ -n "${PREV:-}" ] && [ "$PREV" -gt 0 ] 2>/dev/null; then
                DROP=$(( 100 - SZ*100/PREV ))
                if [ "$DROP" -ge "$SHRINK_PCT" ]; then
                    say WARN "库 [$db] 最新备份 ${SZ}B 较上次 ${PREV}B 缩减 ${DROP}%（≥${SHRINK_PCT}%）—— 须确认是否为业务变化"
                else
                    say PASS "库 [$db] $BN（${AGE}h 前，${SZ}B，gzip 完整，较上次 $([ "$DROP" -lt 0 ] && echo "增长$(( -DROP ))%" || echo "缩减${DROP}%")）"
                fi
            else
                say PASS "库 [$db] $BN（${AGE}h 前，${SZ}B，gzip 完整；无历史可比对）"
            fi
        done
        echo "           ※ gzip 完整 ≠ 可恢复 —— 最终以 restore 演练为准"
    fi
fi

# ---- 5. 逻辑备份日志 ----
echo
if [ ! -r "$LOGICAL_LOG" ]; then
    say ERROR "logical_backup.log 不可读：$LOGICAL_LOG"
else
    E=$(tail -200 "$LOGICAL_LOG" | grep -ciE 'error|failed|sorry|command not found|No such file|无法|拒绝' || true)
    [ "$E" -eq 0 ] && say PASS "logical_backup.log 近 200 行无错误关键字" \
                   || say FAIL "★ logical_backup.log 近 200 行有 $E 处错误关键字"
fi

# ---- 6. cron 两域分别确认 ----
CRON_SYS=/etc/cron.d/KINGBASECRON
CRON_OK=1; CR_U=""; CR_S=""
if CR_U=$(crontab -l 2>&1); then RC_U=0; else RC_U=$?; fi
case "$RC_U" in
  0) : ;;
  1) if printf '%s\n' "$CR_U" | grep -qiE 'no crontab'; then CR_U=""
     else say ERROR "crontab -l 返回 1 但非「no crontab」"; CRON_OK=0; CR_U=""; fi ;;
  *) say ERROR "crontab -l 执行异常(rc=$RC_U)"; CRON_OK=0; CR_U="" ;;
esac
if [ ! -e "$CRON_SYS" ]; then CR_S=""
elif [ ! -r "$CRON_SYS" ]; then say ERROR "$CRON_SYS 存在但无权读取"; CRON_OK=0
elif ! CR_S=$(cat "$CRON_SYS" 2>&1); then say ERROR "读取 $CRON_SYS 失败"; CRON_OK=0; CR_S=""; fi

CR=$(printf '%s\n%s\n' "$CR_U" "$CR_S")
if [ "$CRON_OK" != 1 ]; then
    say ERROR "cron 域证据不完整 —— 不进行计数"
elif [ -z "$(printf '%s' "$CR" | tr -d '[:space:]')" ]; then
    say ERROR "两个 cron 域均为空"
else
    ACTIVE=$(printf '%s\n' "$CR" | grep -Ev '^[[:space:]]*(#|$)' || true)
    for kv in "backup8.sh:$(printf '%s\n' "$ACTIVE" | grep -Fc 'backup8.sh' || true)" \
              "sys_rman full:$(printf '%s\n' "$ACTIVE" | grep -Ec 'sys_rman.*--type=full' || true)" \
              "sys_rman incr:$(printf '%s\n' "$ACTIVE" | grep -Ec 'sys_rman.*--type=incr' || true)"; do
        nm=${kv%%:*}; c=${kv##*:}
        case "$c" in
          1) say PASS "cron $nm 活动行 = 1";;
          0) say FAIL "cron $nm 活动行 = 0 —— 备份已静默停止";;
          *) say FAIL "cron $nm 活动行 = $c —— 重复备份";;
        esac
    done
fi

# ---- 7. repo 空间 ----
if U=$(df -P "$REPO" 2>/dev/null | awk 'NR==2{gsub(/%/,"",$5); print $5}') && [ -n "$U" ]; then
    [ "$U" -lt "$REPO_USED_WARN" ] && say PASS "repo 文件系统已用 ${U}%" \
                                   || say FAIL "repo 文件系统已用 ${U}% ≥ ${REPO_USED_WARN}%"
else say ERROR "无法获取 repo 空间使用率"; fi

echo
kb_summary "备份健康巡检"
