# KingbaseES V8R6 巡检与备份脚本集 **v1.1.7**

> **交付政策（v1.1.7 统一，取代 v1.1.6 的相反表述）**
>
> 本 `kb_scripts_v1.1.7.tar.gz` 是**脚本集自身**的增量包，不含采集脚本 `kbdc.sh`；
> 但**最终发布 ZIP 的根目录必须同时包含 `kbdc.sh`（`kb_collect_all.sh` v1.2.5）**，
> 批准 SHA256 `5c04873b750c5a74f64ddae73b8b946116ddadf30f68e746a445243f4ba80d5c`。
>
> 原因：基线重新冻结的唯一前提就是「用 v1.2.5 复采」。v1.1.1 的发布包曾经漏掉它，
> 按包执行的人拿不到采集脚本；v1.1.6 的 README 又写成「单独交付」，与部署文档
> 「必须与脚本集一同交付」直接冲突。**以部署文档口径为准：缺 `kbdc.sh` 即不得发布。**

## v1.1.7 修的是什么

| # | 级别 | 问题 | 修法 |
| --- | --- | --- | --- |
| 1 | **P1** | **`kb_backup_check.sh` 的 `kq()` 仍未带 `-w`** —— v1.1.6 的 README 与 `backup8.conf` 都已更正「`-w` 与 `-W` 相反」并宣称「凭据三处错误全部修完」，**但巡检脚本漏改**，还保留着 v1.1.5 的错误推理注释。**文档声称的修复与代码实际状态不一致**，这正是本包发生过一次的老毛病（附录内嵌脚本与发布包漂移） | 连接参数统一为 `KSQL_OPTS=(-h … -p … -U … -d … -w)`；删除那两行旧注释 |
| 2 | **P1** | 连通性失败只报一句「数据库连接失败」，原因被 `2>/dev/null` 吞掉 —— 缺 `.kbpass` / 服务未起 / 认证失败在现场是**三种完全不同的处置** | 第 0 项改用**保留 stderr 的探针** `kq_probe()`，ERROR 消息带出首行原因；其余查询仍丢弃 stderr |
| 3 | **P1** | **步骤 4 的 `du -sb` 造成安全型假 FAIL** —— `du` 把目录自身的 apparent size 也算进去，且**目标端的 marker 被计入字节侧、却已被文件数侧排除**：两侧口径不一致，`REFRESH_MODE` 下几乎**必然**报「字节数不一致」。表现为：带 `--delete` 的 dry-run 为空、文件数一致、数据文件全部一致，却因几十字节的目录元数据差异终止 | 改为**只累计普通文件字节数，两端都排除 marker** |
| 4 | **P2** | 静止窗口的 `find … \| head -5` 在 `set -o pipefail` 下，最近修改文件很多时 `head` 提前关管道 → GNU `find` 收到 SIGPIPE → 管道 rc=141，脚本把「repo 明显仍在变化」报成 **ERROR（证据缺失）**而不是 **FAIL**。仍然阻断，但状态语义不准确（实测 6000 个最近文件即复现 rc=141） | 判定改用 `-print -quit`（命中即停，不经管道）；展示用的列表放进**显式关闭 pipefail** 的子 shell |
| 5 | **P2** | `kb_log_cleanup.sh` 的 `ALLOW_PREFIX` 只覆盖 `/data/kingbase/log`。三容量域方案一旦把日志改到备份卷，脚本会以「白名单之外」拒绝执行 —— **日志保留策略静默停止** | 白名单同时覆盖两版存储方案的日志路径，仍固定在脚本内、**不接受环境变量覆盖** |
| 6 | **P2** | `findmnt` 是挂载点身份断言的取证命令，却不在执行前硬门的命令清单里；`du` 已不再使用 | 硬门清单补 `findmnt`、移除 `du` |
| 7 | — | 交付政策自相矛盾（见上方） | 统一为「发布 ZIP 必须含 `kbdc.sh`」 |

> **本轮未改动逻辑的文件**：`kb_lib.sh`、`kb_ha_watch.sh`、`backup8.conf`（仅版本字符串与注释）。

### 凭据方案：三处更正到 v1.1.7 才算真正落地

| 项 | 曾经的错误 | 正确 | 落地版本 |
| --- | --- | --- | --- |
| 环境变量名 | `KBPASSFILE` | **`KINGBASE_PASSFILE`**（默认位置本就是 `~/.kbpass`，通常无需设置） | v1.1.6 |
| `-w` 参数 | 因现场注释「不能加 `-W`」而**撤销了 `-w`** | **两者相反**：`-w` = `--no-password`（禁止交互，**批处理正需要**）；`-W` = `--password`（强制提示，无人值守本就不该加）。现场证据**只否定了 `-W`** | `backup8.conf` v1.1.6；**`kb_backup_check.sh` v1.1.7** |
| 连接 host | 未显式带 `-h` | **必须带 `-h`** —— `.kbpass` 首列按实际连接的 host 匹配；不带 `-h` 时匹配目标是 `localhost` 而非 `127.0.0.1` | `backup8.conf` v1.1.6；**`kb_backup_check.sh` v1.1.7** |

> ⚠️ 按基线 **P0-20** 要求，须在现场真实跑通后再替换现有凭据。
> 跑通前 `kb_backup_check.sh` 会**立即**报「数据库连接失败：…」并带出原因 —— 这是 `-w` 的预期行为，不是新故障。

## 文件清单（★ 七个文件必须全部落地）

| 文件 | 说明 | 身份 | 权限 |
| --- | --- | --- | --- |
| `kb_lib.sh` | **公用库**：四态判定 / Paused 表头解析 / `kb_ping_ok` / `kb_role` / `kb_need_int`。**禁止直接执行** | — | **640** |
| `kb_backup_check.sh` | 备份健康巡检（按库核对 + `gzip -t`） | kingbase | 750 |
| `kb_ha_watch.sh` | HA 静默降级巡检 | kingbase | 750 |
| `kb_offcluster_copy.sh` | off-cluster 副本（受控停写） | kingbase | 750 |
| `kb_log_cleanup.sh` | 数据库日志保留（**唯一不 source `kb_lib.sh` 的脚本**，自实现 fail-closed，避免删除类脚本依赖外部文件） | kingbase | 750 |
| `backup8.conf` | 逻辑备份配置**建议稿** | kingbase | 600 |
| `SHA256SUMS` | **哈希清单** —— 版本字符串只能说明文件"自称"哪一版，哈希才说明拿到的是哪份字节 | — | 644 |

> **另需随发布 ZIP 交付**：`kbdc.sh`（v1.2.5，root 身份执行，750，放 `/tmp` 或 `/root`）。

## 核心约定：ERROR 与 FAIL 同样阻断

**「取不到证据」不等于「通过」。** 四条实现原则：

1. **命令执行成功且结果为空 → PASS；命令本身失败 → ERROR。** 不能用同一个 `else` 分支表达这两种语义。
2. 取证命令（`lsof`/`ip`/`pgrep`/`fuser`/`find`/`df`/SQL）**必须先确认执行成功**，才能把「无匹配」解释成「确实没有」。
   > ⚠️ **返回码相同不代表语义相同** —— v1.1.6 的 `lsof` 是这一条的反例（rc=1 既可能是"无占用"也可能是"扫描失败"）；v1.1.7 的 `find | head` 是另一个反例（rc=141 是 SIGPIPE，不是扫描失败）。
3. 缺少必需命令或目录 → **执行前硬门直接终止**。
4. **（v1.1.7 新增）阻断类判据的口径必须两端一致。** 同一件事用两个指标校验时（字节数 / 文件数），排除规则必须相同，否则得到的是**系统性假 FAIL** —— 它不会放过坏数据，但会让正确的复制永远无法通过验收，进而诱使现场"临时绕过校验"。

## 部署（★ node1 / node2 **分别**执行）

```bash
scp kb_lib.sh kb_backup_check.sh kb_ha_watch.sh kb_offcluster_copy.sh \
    kb_log_cleanup.sh backup8.conf SHA256SUMS README.md \
    kingbase@<节点>:/home/kingbase/backup_script/
```

```bash
cd /home/kingbase/backup_script
sha256sum -c SHA256SUMS          # ★ 必须全部 OK，任一 FAILED 即停止
file kb_*.sh                     # 应无 "CRLF line terminators"
chmod 750 kb_backup_check.sh kb_ha_watch.sh kb_offcluster_copy.sh kb_log_cleanup.sh
chmod 640 kb_lib.sh              # ★ 不给执行位
chmod 600 backup8.conf
```

## 依赖预检

```bash
for c in ssh rsync pgrep awk df find findmnt lsof gzip ping mktemp; do
    command -v "$c" >/dev/null || echo "★ 缺少 $c —— 自测结果不可信"
done
```

> **`lsof` 尤其重要**：`kb_offcluster_copy.sh` 无 lsof 时只能用 `fuser -m`（范围是整个文件系统而非 repo 目录），届时需 `ALLOW_NO_LSOF=yes` 显式降级。**建议两个数据库节点都装 lsof。**
>
> ⚠️ **缺依赖会改变自测的失败原因**：例如无 `rsync` 时，offcluster 那一项会停在「缺少必需命令 rsync」而不是「repo 目录不存在」，表现为「rc 正确但未命中预期原因」。**先跑依赖预检，再跑自测。**

## 故障注入自测（★ 接入 cron 前必做，rc 与原因双校验）

```bash
cd /home/kingbase/backup_script
t(){ local name=$1 kw=$2; shift 3; local out rc
     out=$("$@" 2>&1); rc=$?
     printf '  %-42s' "$name"
     if [ "$rc" -ne 1 ]; then echo "★ 预期 rc=1，实际 rc=$rc"; return; fi
     printf '%s' "$out" | grep -q -- "$kw" \
        && echo "OK (rc=1，命中「$kw」)" \
        || echo "★ rc 正确但未命中预期原因「$kw」"; }

t "backup_check：依赖全失败"       "数据库连接失败"  -- env KB_HOME=/nonexistent REPO=/nonexistent DUMP=/nonexistent LOGICAL_LOG=/nonexistent bash kb_backup_check.sh
t "backup_check：MAX_FULL_AGE_H=abc" "必须为正整数" -- env MAX_FULL_AGE_H=abc bash kb_backup_check.sh
t "backup_check：SHRINK_PCT=0"      "超出允许区间"  -- env SHRINK_PCT=0 bash kb_backup_check.sh
t "ha_watch：repmgr 与配置不可用"   "无法从"        -- env KB_HOME=/nonexistent REPMGR_CONF=/nonexistent bash kb_ha_watch.sh
t "log_cleanup：白名单外目录"       "白名单之外"    -- bash kb_log_cleanup.sh /tmp
t "log_cleanup：目录不存在"         "目录不存在"    -- bash kb_log_cleanup.sh /nonexistent
t "log_cleanup：KEEP_DAYS=-1"       "必须为正整数"  -- env KEEP_DAYS=-1  bash kb_log_cleanup.sh /data/kingbase/log
t "log_cleanup：USED_WARN=abc"      "必须为正整数"  -- env USED_WARN=abc bash kb_log_cleanup.sh /data/kingbase/log
t "offcluster：repo 不存在"         "repo 目录不存在" -- env REPO=/nonexistent bash kb_offcluster_copy.sh 10.255.255.1 /tmp/x
t "kb_lib 禁止直接执行"             "请用 source"   -- bash kb_lib.sh
```

**十项必须全部 `OK`。** `rc=127` 说明**文件没部署全**；「rc 正确但未命中原因」说明**测到了别的分支**——都不是通过。

### 静态回归自检（v1.1.7 新增，3 类断言，接在故障注入之后跑）

> 本轮的第 1 项正是「README 宣称已修、代码其实没改」。故障注入测不到这类问题，
> 必须用静态断言把**已修复的事实**钉在包里。

```bash
cd /home/kingbase/backup_script
grep -qE 'KSQL_OPTS=\(.*-w\)' kb_backup_check.sh \
   && echo "OK  backup_check 连接参数含 -w" || echo "★ backup_check 缺 -w（回归）"
grep -vE '^[[:space:]]*#' kb_offcluster_copy.sh | grep -q 'du -sb' \
   && echo "★ offcluster 仍在用 du -sb（回归）" || echo "OK  offcluster 字节比对已按普通文件累计"   # ★ 先滤掉注释行：v1.1.7 的注释里保留了"不能用 du -sb"的原因说明
for f in kb_lib.sh kb_backup_check.sh kb_ha_watch.sh kb_offcluster_copy.sh kb_log_cleanup.sh backup8.conf; do
    grep -q '1\.1\.7' "$f" && echo "OK  $f 声明 v1.1.7" || echo "★ $f 未声明 v1.1.7"
done
```

**全部为 `OK`；出现任一 `★` 即说明拿到的不是 v1.1.7 的字节。**

## 已知边界

| 项 | 边界 |
| --- | --- |
| `EXPECT_REPO_MOUNT` | **与三容量域方案直接耦合**，默认 `/data`，必须按现场实际取值，否则每次都被硬门挡下：<br>· **现场版（存储改造前）**：repo 仍在根盘 → `EXPECT_REPO_MOUNT=/`<br>· **建议版（备份卷挂 `/data`）** → `/data`<br>· **建议版（备份卷挂 `/data/kingbase/backup`）** → `/data/kingbase/backup`<br>现场取值命令：`findmnt -no TARGET -T "$REPO"` |
| `kb_log_cleanup.sh` 白名单 | 白名单已覆盖两版方案的日志路径，但**实际清理哪个目录由命令行参数 / cron 行决定** —— 存储方案落地时必须同步改 cron 里的路径，白名单不会替你改 |
| GNU `findutils` 依赖 | 字节比对用 `find -printf`，**源端与目标端都必须是 GNU find**（本现场 Kylin V10 满足）。目标端若为 BusyBox / BSD，需改用 `find … -exec stat -c %s {} +` |
| `trusted_servers` 检查 | 实测 `hamgr.log` 显示 repmgrd 正常状态下**不做该探测**，只在察觉连接异常时触发。本项是「**等价预检**」，**不是**「当前正在失败」的告警。<br>⚠️ repmgr 内部实际使用的命令与判据**仍未查证**，建议在 C 类演练中通过临时指向不可达地址观测 |
| `sys_rman info` 解析 | ✅ **已于 2026-09-09 在 PS062 两节点现场验证**，成功解析 full / incr 时间戳 |
| 逻辑备份判据 | 「产物新鲜 + `gzip -t` 完整 + 日志无错误」**不等于可恢复**，最终以 **restore 演练**为准 |
| off-cluster 校验 | 带 `--delete` 的 dry-run + 字节数 + 文件数三重比对，属**镜像一致性**校验，**不证明可恢复** |
| `kb_log_cleanup.sh` | 唯一不 source `kb_lib.sh` 的脚本 —— 删除类脚本刻意不依赖外部文件 |

## 变更记录

| 版本 | 说明 |
| --- | --- |
| v1.1 ~ v1.1.4 | 见历史包 README |
| v1.1.5 | ping 判据改收包数；角色改用 `standby.signal`；逻辑备份排除 `backup_log_*`、按库核对、`gzip -t` 替代字节阈值；`kb_lib.sh` 禁止直接执行 |
| v1.1.6 | **P0**：`lsof rc=1` 的 fail-open —— 扫描失败与无占用返回码相同，改为**捕获 stderr 三分**。<br>**P1**：`REFRESH_MODE` 的 marker 被自身 `--delete` 删除，三处 rsync 统一 `--exclude`；凭据方案三处更正（`KINGBASE_PASSFILE`、恢复 `-w`、显式 `-h`）**—— 但只在 `backup8.conf` 落地**；HA 对 `trusted_servers` 的结论收窄为「等价预检」；六个数值参数入口统一校验（`kb_need_int`）。<br>**P2**：`kb_ping_ok` 固定 `LC_ALL=C`；新增 `SHA256SUMS`；`sys_rman info` 边界更新为「已现场验证」。 |
| **v1.1.7** | **P1**：`kb_backup_check.sh` 补 `-w` 并删除 v1.1.5 的错误注释（v1.1.6 宣称已修、实际漏改）；连通性 ERROR 带出失败原因。<br>**P1**：off-cluster 字节比对由 `du -sb` 改为**按普通文件累计、两端排除 marker**，消除 `REFRESH_MODE` 下的系统性假 FAIL。<br>**P2**：静止窗口 `find \| head` 的 SIGPIPE 误报（rc=141 → ERROR）改用 `-print -quit`；`kb_log_cleanup.sh` 白名单覆盖两版存储方案；硬门命令清单补 `findmnt`、移除 `du`。<br>**交付**：统一为「发布 ZIP 必须含 `kbdc.sh` v1.2.5」；新增**静态回归自检**。 |
