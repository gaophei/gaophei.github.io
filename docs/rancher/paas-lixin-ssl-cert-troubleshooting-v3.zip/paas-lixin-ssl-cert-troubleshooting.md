# *.paas.lixin.edu.cn 内外网 SSL 证书不一致排查记录

| 项目 | 内容 |
|---|---|
| 系统 | 上海立信会计金融学院 智慧校园云平台（`*.paas.lixin.edu.cn`） |
| 排查日期 | 2026-10-12 ～ 2026-10-13 |
| 排查人 | （填写） |
| 当前状态 | **外网已恢复**：2026-10-12 高防平台与内网 WAF 已更换为新证书。<br>**移动端已恢复**：2026-10-13 移动立信 App 手机端登录报"网络错误"，原因是 WAF 上的证书缺少中间证书，补齐后恢复（见第 9 节）。<br>**遗留问题**：高防与内网 WAF 补链后的链长复测待补充（8.1、8.4）；两台内网机器仍显示旧证书；3 个命名空间的 Ingress 仍引用 `nginxssl-2024`（见第 7 节） |
| 紧急程度 | **高**：旧证书 2026-10-23 23:59:59 到期，仍引用旧 secret 的 Ingress 必须在此之前处理 |

**修订记录**

| 版本 | 日期 | 内容 |
|---|---|---|
| v1 | 2026-10-12 | 问题描述、定位过程与结论 |
| v2 | 2026-10-12 | 补充换证后外网验证、证书包核查、Rancher 证书核查、堡垒机基线、Windows 2012 兼容性说明；更新定位结论与遗留事项 |
| v3 | 2026-10-13 | 新增第 9 节：移动立信 App 手机端"网络错误"故障的现象、排查过程与证据、根因、处置、验证和经验；同步更新 1.4、4.1、4.3、5.1、5.2、6.1、7.2、第 8 节 |

---

## 1. 问题描述

### 1.1 环境

平台部署在 Rancher（RKE1）集群中。ingress-nginx 以 DaemonSet 形式运行在 8 个工作节点（192.168.253.25–30、192.168.253.44、192.168.253.45）的 443 端口。

前端服务器 nginx01 的网卡直接配置公网地址 `202.121.255.182/27`，用 nginx stream 模块做四层透传，并开启 `proxy_protocol` 把客户端地址传给 ingress-nginx。

HTTPS 证书配置在 Rancher 负载均衡（Ingress）中，已于 2026-10-10 更换为新证书。

### 1.2 现象

1. 在与 Rancher 工作节点同网络的 Windows 堡垒机中访问平台域名，浏览器显示**新证书**。
2. 在堡垒机以外的网络访问同一域名，浏览器显示**旧证书**。
3. 学校老师关闭 WAF 后，外网访问仍为**旧证书**。

### 1.3 新旧证书对照（时间为北京时间）

| 字段 | 新证书（Rancher 中已配置） | 旧证书（外网实际看到） |
|---|---|---|
| 使用者 CN | `*.paas.lixin.edu.cn` | `*.paas.lixin.edu.cn` |
| 颁发者 | SHECA DV TLS RSA CA A1（O=UniTrust） | SHECA DV Server CA G5（O=UniTrust） |
| 生效时间 | 2026-10-10 15:50:28 | 2025-09-23 13:50:09 |
| 到期时间 | 2027-04-26 23:59:59 | **2026-10-23 23:59:59** |
| SHA-256 指纹 | `AA:C6:69:78:DE:AA:B6:67:32:00:60:93:6A:33:0E:A1:97:DB:7F:99:38:88:65:4F:7C:C1:4E:34:5E:7C:8D:D2` | `3d7be45e6cbb4cabdaee04c733c3bcced58dcf6e6d9003ffadd651e40db73b79` |

新旧证书的中间 CA 不同（A1 / G5），部署时须使用包含新中间证书的完整证书链。

### 1.4 后续情况（v2 补充）

- **2026-10-12：** 老师在高防平台（103.41.1.37）和内网 WAF 上更换了证书，外网访问恢复正常。
- **仍有异常：** 内网有两台机器访问仍返回旧证书（可能也是 Windows 2012）。目前没有这两台的登录权限，待 2026-10-13 老师开远程后核查（见 7.1）。
- **2026-10-13（v3 补充）：** 移动立信 App（`superapp.paas.lixin.edu.cn`）在手机端登录时报"网络错误"，PC 网页正常。定位为 WAF 上配置的证书缺少中间证书，补齐后恢复（见第 9 节）。

---

## 2. 排查思路

nginx01 是四层透传，本身不持有证书。正常情况下 TLS 只在 ingress-nginx 终结一次。外网看到旧证书只有两种可能：外网路径上另有设备先终结了 TLS，或者外网流量被引到了另一个后端。

排查方法是对同一个域名（同一个 SNI），分别在源站本机、校内、外网取证书，对比以下几项，找出旧证书出现的位置：

- 证书指纹
- ALPN 协商结果（h2 / http/1.1）
- 实际连接的目标 IP

---

## 3. 排查过程（定位阶段）

### 3.1 命令执行主机说明

| 主机 | 位置 / 用途 |
|---|---|
| Windows 堡垒机 | 校内，与 Rancher 工作节点同网络；Windows Server 2012 R2（6.3.9600），PowerShell 4.0 |
| 外网 Windows 终端 | 堡垒机以外，浏览器测试 |
| nginx01 | 源站四层代理，公网地址 202.121.255.182 |
| 集群管理机 | 执行 kubectl |
| mysql | 外网服务器，OpenSSL 1.1.1k |
| harbor | 测试机，出口 IP 101.231.137.170 |
| dbserver | 执行 whois 查询 |
| 本地解包环境 | 核查证书包 NGINX.zip，OpenSSL 3.0.13 |

### 3.2 浏览器现象对比

第一轮对比时两侧访问的不是同一个域名：堡垒机访问的是 `admin-platform`（图 1），外网访问的是 `portal-theme`（图 2）。由于 ingress-nginx 按 SNI 为每个 host 选择证书，第二轮统一改为测试 `portal-theme.paas.lixin.edu.cn`（图 3、图 4）。

| 访问位置 | DevTools 远程地址 | 证书 | HTTP 版本依据 |
|---|---|---|---|
| 堡垒机（图 3） | 202.121.255.182:443 | 新（A1，至 2027-04-26） | 请求头含 `:authority`、`:path` 等伪头部 → **HTTP/2** |
| 外网 Windows（图 4） | 202.121.255.182:443（见 7.7，已解释） | 旧（G5，至 2026-10-23） | 响应头含 `Connection: keep-alive`、`Transfer-Encoding: chunked`（HTTP/2 禁止这两个头）→ **HTTP/1.1** |

分析：

- **HTTP 版本不同。** ingress-nginx 默认支持 HTTP/2，外网只协商到 HTTP/1.1，说明外网 TLS 握手的对象不是 ingress-nginx。
- **请求最终仍到达 ingress。** 外网响应头仍有 `Strict-Transport-Security: max-age=15724800; includeSubDomains`（ingress-nginx 默认 HSTS 值），页面也返回实时数据（最近登录时间）。所以中间设备是转发代理，不是一台独立的旧服务器。

![图1 堡垒机访问 admin-platform，新证书](images/fig1-bastion-admin-platform-new-cert.png)

![图2 外网访问 portal-theme，旧证书](images/fig2-external-portal-theme-old-cert.png)

![图3 堡垒机访问 portal-theme，新证书，HTTP/2](images/fig3-bastion-portal-theme-new-cert-h2.png)

![图4 外网访问 portal-theme，旧证书，HTTP/1.1](images/fig4-external-portal-theme-old-cert-http11.png)

### 3.3 nginx01 配置核查

```text
[root@nginx01 ~]# cat /etc/nginx/nginx.conf
user  nginx;
worker_processes  4;
worker_rlimit_nofile 40000;

error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;

events {
    worker_connections 8192;
}

stream {
    # （80 端口 work_servers_http 的 upstream 和 server 均已注释，此处略）

    upstream work_servers_https {
        least_conn;
        server 192.168.253.25:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.26:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.27:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.28:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.29:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.30:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.44:443 max_fails=3 fail_timeout=5s;
        server 192.168.253.45:443 max_fails=3 fail_timeout=5s;
    }
    server {
        listen     443;
        proxy_pass work_servers_https;
        proxy_protocol on;
    }
}
```

```text
[root@nginx01 ~]# ip a
...
2: ens160: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:50:56:93:1e:94 brd ff:ff:ff:ff:ff:ff
    inet 202.121.255.182/27 brd 202.121.255.191 scope global noprefixroute ens160
       valid_lft forever preferred_lft forever
```

**结论：**

- 只有 stream 四层透传，没有 `http` 块，也没有 `ssl_certificate`，nginx01 不出示任何证书。
- 公网地址直接配在本机网卡上，源站前没有 DNAT。

### 3.4 源站证书与 ALPN（在 nginx01 本机测试）

取证书函数：

```bash
chk() {
  echo | timeout 5 openssl s_client -connect "$1:443" -servername "$2" 2>/dev/null \
  | openssl x509 -noout -issuer -enddate -fingerprint -sha256
}
```

```text
[root@nginx01 ~]# chk 202.121.255.182 portal-theme.paas.lixin.edu.cn
issuer=C=CN, O=UniTrust, CN=SHECA DV TLS RSA CA A1
notAfter=Apr 26 15:59:59 2027 GMT
sha256 Fingerprint=AA:C6:69:78:DE:AA:B6:67:32:00:60:93:6A:33:0E:A1:97:DB:7F:99:38:88:65:4F:7C:C1:4E:34:5E:7C:8D:D2
```

```text
[root@nginx01 ~]# openssl s_client -connect 202.121.255.182:443 -servername portal-theme.paas.lixin.edu.cn \
>   -alpn h2,http/1.1 </dev/null 2>/dev/null | grep -E 'ALPN|Protocol|Cipher|issuer'
issuer=C=CN, O=UniTrust, CN=SHECA DV TLS RSA CA A1
Verification error: unable to get local issuer certificate
New, TLSv1.3, Cipher is TLS_AES_256_GCM_SHA384
Protocol: TLSv1.3
ALPN protocol: h2
Verify return code: 20 (unable to get local issuer certificate)
```

**结论：**

- 源站（nginx01 → ingress-nginx）出示新证书，TLS 1.3，ALPN 协商为 h2，与堡垒机浏览器一致。
- 本机测试不经过任何外部网络设备，只能证明源站本身正常。
- `Verify return code: 20` 已在 6.3 核查：源站下发的证书链完整，此报错属 nginx01 本机信任库原因。

### 3.5 nginx01 的 443 连接来源分布

```text
[root@nginx01 ~]# ss -tn state established '( sport = :443 )' | awk 'NR>1{split($4,a,":");print a[1]}' | sort | uniq -c | sort -rn | head
     57 10.46.186.248
     29 103.41.164.49
     26 10.31.4.21
     22 172.31.246.34
     22 10.35.25.41
     18 103.41.164.51
     17 10.46.207.118
     13 192.168.253.44
     13 10.31.95.34
     11 103.41.164.48
```

**分析：**

- **103.41.164.48 / .49 / .51：** 同网段的 3 个公网地址保持大量连接，3.7 节确认它们是高防/云 WAF 的回源节点。
- **10.x、172.31.x：** 校内用户直接访问源站。
- **192.168.253.44：** 集群工作节点（推测为集群内服务访问本平台域名）。

### 3.6 外网测试（mysql 外网服务器）

#### 3.6.1 外网直连源站 IP

```text
[root@mysql ~]# openssl version
OpenSSL 1.1.1k  FIPS 25 Mar 2021
[root@mysql ~]# echo | openssl s_client -connect 202.121.255.182:443 -servername portal-theme.paas.lixin.edu.cn 2>&1 | head -30

140280160597824:error:0200206E:system library:connect:Connection timed out:crypto/bio/b_sock2.c:110:
140280160597824:error:2008A067:BIO routines:BIO_connect:connect error:crypto/bio/b_sock2.c:111:
connect:errno=110
```

**结论：** 源站 202.121.255.182:443 不对公网开放，外网无法直连。

#### 3.6.2 外网按域名访问

```text
[root@mysql ~]# curl -vk --max-time 10 https://portal-theme.paas.lixin.edu.cn/ -o /dev/null 2>&1 | grep -iE 'connected|SSL|TLS|subject|issuer|expire|ALPN|HTTP/'
* Connected to portal-theme.paas.lixin.edu.cn (103.41.1.37) port 443 (#0)
  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0* ALPN, offering h2
* ALPN, offering http/1.1
*   CAfile: /etc/pki/tls/certs/ca-bundle.crt
* TLSv1.3 (OUT), TLS handshake, Client hello (1):
* TLSv1.3 (IN), TLS handshake, Server hello (2):
* TLSv1.3 (IN), TLS handshake, [no content] (0):
* TLSv1.3 (IN), TLS handshake, Encrypted Extensions (8):
* TLSv1.3 (IN), TLS handshake, [no content] (0):
* TLSv1.3 (IN), TLS handshake, Certificate (11):
* TLSv1.3 (IN), TLS handshake, [no content] (0):
* TLSv1.3 (IN), TLS handshake, CERT verify (15):
* TLSv1.3 (IN), TLS handshake, [no content] (0):
* TLSv1.3 (IN), TLS handshake, Finished (20):
* TLSv1.3 (OUT), TLS change cipher, Change cipher spec (1):
* TLSv1.3 (OUT), TLS handshake, [no content] (0):
* TLSv1.3 (OUT), TLS handshake, Finished (20):
* SSL connection using TLSv1.3 / TLS_AES_256_GCM_SHA384
* ALPN, server accepted to use http/1.1
*  subject: CN=*.paas.lixin.edu.cn
*  expire date: Oct 23 15:59:59 2026 GMT
*  issuer: C=CN; O=UniTrust; CN=SHECA DV Server CA G5
*  SSL certificate verify ok.
* TLSv1.3 (OUT), TLS app data, [no content] (0):
> GET / HTTP/1.1
* TLSv1.3 (IN), TLS handshake, [no content] (0):
* TLSv1.3 (IN), TLS handshake, Newsession Ticket (4):
* TLSv1.3 (IN), TLS handshake, [no content] (0):
* TLSv1.3 (IN), TLS handshake, Newsession Ticket (4):
* TLSv1.3 (IN), TLS app data, [no content] (0):
< HTTP/1.1 200 OK
< Set-Cookie: https_waf_cookie=1b868a26-c678-479f4f26d538c981f2579d7fb0bd26292591; Expires=1791796715; Path=/; Secure; HttpOnly
< Expires: Mon, 12 Oct 2026 07:18:35 GMT
```

**结论：**

1. 外网解析 `portal-theme.paas.lixin.edu.cn` 得到 **103.41.1.37**，不是源站 202.121.255.182。
2. 103.41.1.37 出示的是**旧证书**（G5，`expire date: Oct 23 15:59:59 2026 GMT`）。
3. ALPN 只接受 http/1.1，与图 4 的 HTTP/1.1 现象一致。
4. 响应中带 `https_waf_cookie`，是 WAF 的特征 Cookie。

### 3.7 IP 归属查询

```text
[root@dbserver ~]# whois 103.41.1.37   | grep -iE 'netname|descr|org|country'
netname:        HJ-HIDDOS
descr:          Hebei Sea Whale Technology Co. Ltd..
country:        CN
country:        CN
[root@dbserver ~]# whois 103.41.164.49 | grep -iE 'netname|descr|org|country'
netname:        HJ-HIDDOS
descr:          Hebei Sea Whale Technology Co. Ltd..
country:        CN
country:        ZZ
country:        CN
```

**结论：**

- 外网入口 103.41.1.37 与回源地址 103.41.164.x 属于同一服务商：netname `HJ-HIDDOS`，登记单位 Hebei Sea Whale Technology Co. Ltd.。
- 这是一个高防 / 云 WAF 服务：公网入口在其节点上，回源连接也来自其节点。

### 3.8 打标记请求核对 ingress 日志

在测试机上发起带标记的请求：

```text
[root@harbor v6-auto-install]# curl -s ip.sb ; curl -sk -o /dev/null "https://portal-theme.paas.lixin.edu.cn/?probe=outtest1012"
101.231.137.170
```

当前 kubectl 版本不支持 `kubectl logs --prefix`，因此改为逐个 Pod 查询：

```text
> for p in $(kubectl -n ingress-nginx get pod -l app=ingress-nginx -o jsonpath='{.items[*].metadata.name}'); do
>   kubectl -n ingress-nginx logs "$p" --since=15m 2>/dev/null | grep -E 'probe=(outtest|in)1012' | sed "s/^/[$p] /"
> done
（无输出）
```

统计近 5 分钟以 `103.41.` 开头的访问日志：

```text
> for p in $(kubectl -n ingress-nginx get pod -l app=ingress-nginx -o jsonpath='{.items[*].metadata.name}'); do
>   echo "== $p  $(kubectl -n ingress-nginx logs "$p" --since=5m | grep -c '^103\.41\.')"
> done
== nginx-ingress-controller-ffkdf  0
== nginx-ingress-controller-hsn6l  0
== nginx-ingress-controller-k44lf  0
== nginx-ingress-controller-lmrmx  0
== nginx-ingress-controller-nc26k  0
== nginx-ingress-controller-nkbpk  0
== nginx-ingress-controller-pw5bz  0
== nginx-ingress-controller-wdpt2  0
```

确认 Pod 标签无误：

```text
> kubectl -n ingress-nginx get pod --show-labels
NAME                                    READY   STATUS    RESTARTS   AGE      LABELS
default-http-backend-67cf578fc4-2z8gp   1/1     Running   89         6y172d   app=default-http-backend,pod-template-hash=67cf578fc4
nginx-ingress-controller-ffkdf          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-hsn6l          1/1     Running   1          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-k44lf          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-lmrmx          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-nc26k          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-nkbpk          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-pw5bz          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
nginx-ingress-controller-wdpt2          1/1     Running   0          29h      app=ingress-nginx,controller-revision-hash=849847cc8c,pod-template-generation=23
```

**分析：**

- 标签正确，8 个 controller Pod 都查到了，查询循环本身没有问题。
- probe 请求未出现在日志中。较可能的原因是：未携带 Cookie 的 curl 请求被 WAF 首访 Cookie 校验拦下（3.6.2 中的 `200 OK` 加 `Set-Cookie: https_waf_cookie`），没有回源。
- `103.41.` 计数为 0，与 3.5 中大量来自 103.41.164.x 的已建立连接相矛盾。这不影响本次结论，但需要核实日志格式和访问日志开关，列入 7.5。

### 3.9 平台 Ingress 域名清单

```text
> kubectl get ingress -A -o jsonpath='{range .items[*]}{.spec.rules[*].host}{"\n"}{end}' \
>   | tr ' ' '\n' | grep 'paas.lixin.edu.cn' | sort -u > /tmp/hosts.txt
> cat /tmp/hosts.txt
admin-platform.paas.lixin.edu.cn
authx-service.paas.lixin.edu.cn
cas-minio.paas.lixin.edu.cn
cas.paas.lixin.edu.cn
cas.paas.lixin.edu.cn123
ds.paas.lixin.edu.cn
echo.paas.lixin.edu.cn
form-design-m.paas.lixin.edu.cn
form-design.paas.lixin.edu.cn
form-space.paas.lixin.edu.cn
formflow.paas.lixin.edu.cn
governance-minio.paas.lixin.edu.cn
message-service.paas.lixin.edu.cn
personal-security-center.paas.lixin.edu.cn
poa.paas.lixin.edu.cn
portal-center-remote.paas.lixin.edu.cn
portal-minio.paas.lixin.edu.cn
portal-service.paas.lixin.edu.cn
portal-theme.paas.lixin.edu.cn
question-feedback.paas.lixin.edu.cn
stuwork.paas.lixin.edu.cn
stuwork1.paas.lixin.edu.cn
stuworkapp.paas.lixin.edu.cn
superapp.paas.lixin.edu.cn
token.paas.lixin.edu.cn
transaction.paas.lixin.edu.cn
```

共 26 条，其中 `cas.paas.lixin.edu.cn123` 为异常 host，见 7.6。

---

## 4. 问题定位

### 4.1 实际访问链路（v2 更新）

```text
【外网用户 · IPv4】
    │  公网解析 → 103.41.1.37
    ▼
103.41.1.37  高防 / 云 WAF（HJ-HIDDOS，Hebei Sea Whale Technology Co. Ltd.）
    │  ★ 终结 TLS。10-12 前出示旧证书，已于 10-12 更换
    │    换证时缺中间证书，10-13 已在 WAF 上补齐（见 7.2、第 9 节）
    │  回源（源地址 103.41.164.48 / .49 / .51 等）
    ▼
202.121.255.182  nginx01（stream 四层透传 + proxy_protocol，不持有证书）
    ▼
192.168.253.x:443  ingress-nginx（Rancher）
    │  多数 Ingress 引用 nginxssl-2026（新证书，链完整）
    │  authx-service / dataassets / stuwork 三个命名空间仍引用 nginxssl-2024（见 7.3）
    ▼
业务 Pod

【外网用户 · IPv6】
    │  公网解析 → 240e:f7:7c00:800:0:1:1:86、240e:f7:7c00:800:0:1:1:c4、2409:8c28:30b0:b::1:b4
    ▼
IPv6 入口节点（归属及证书未单独验证，见 7.4）→ … → 源站

【经过内网 WAF 的访问路径】（覆盖哪些网段待网络老师确认）
    ▼
内网 WAF  ★ 终结 TLS。10-12 前出示旧证书，已于 10-12 更换（补链情况见 7.2）
    ▼
202.121.255.182 → ingress-nginx

【堡垒机】（6.5 基线）
    │  校内 DNS → 202.121.255.182，不经过高防和内网 WAF
    ▼
nginx01 → ingress-nginx → 新证书
```

### 4.2 根因

平台的 HTTPS 证书一共存在于以下几处：

1. **Rancher Ingress（源站）**
2. **HJ-HIDDOS 高防 / 云 WAF（公网 IPv4 入口）**
3. **内网 WAF（部分访问路径上的串接设备）**
4. **可能还有 IPv6 入口节点（待确认）**

公网用户访问时，先到达高防节点 103.41.1.37，由高防用其平台上配置的证书终结 TLS，再通过 103.41.164.x 回源到 nginx01，最终到达 ingress-nginx。经过内网 WAF 的访问路径同理。

2026-10-10 只在 Rancher Ingress 中更换了证书，高防和内网 WAF 上仍是旧证书，所以外网用户和经过内网 WAF 的用户看到旧证书。堡垒机直接访问源站，不经过这两台设备，所以看到新证书。

**"关闭 WAF 后仍是旧证书"的原因：** 只要公网解析仍指向高防节点，TLS 就一直由高防终结。"关闭 WAF"通常只关闭防护规则，代理转发和证书仍然生效。另外，内网 WAF 也持有旧证书，关闭其中一处并不能消除另一处的影响。

### 4.3 证据汇总

| 证据 | 来源 | 说明 |
|---|---|---|
| nginx01 仅四层透传，无证书配置 | 3.3 | nginx01 不可能出示旧证书 |
| 源站出示新证书，ALPN h2，链完整 | 3.4、6.3 | Rancher Ingress 证书已正确更新（引用 nginxssl-2026 的部分） |
| 外网直连源站 443 超时 | 3.6.1 | 源站不对公网开放，外网必然经过前置节点 |
| 外网解析到 103.41.1.37，出示旧证书，ALPN http/1.1 | 3.6.2 | 旧证书由 103.41.1.37 出示 |
| 响应携带 `https_waf_cookie` | 3.6.2 | 前置节点为 WAF |
| 103.41.1.37 与 103.41.164.x 同属 HJ-HIDDOS | 3.7 | 入口节点与回源节点为同一高防服务商 |
| 103.41.164.x 与 nginx01:443 存在大量连接 | 3.5 | 高防回源到源站 |
| 外网浏览器为 HTTP/1.1，校内为 HTTP/2 | 3.2 | 外网握手对象不是 ingress-nginx |
| 高防与内网 WAF 换证后外网恢复，所有域名返回新证书 | 5.1、6.1 | 证实旧证书来自这两处 |
| 手机 App 登录约 0.25 秒内报"网络错误"，PC 网页正常 | 9.3.1、9.3.2 | 请求在连接或 TLS 握手阶段即失败，不是超时 |
| iOS Safari 访问 superapp 提示证书不受信任，而证书有效、域名匹配、带 SCT | 9.3.3 | 下发的证书链缺中间证书 |
| WAF 补齐中间证书后 App 恢复 | 9.5 | 证实 App 故障由证书链不完整引起 |

---

## 5. 处置记录与建议

### 5.1 已完成

| 时间 | 操作 | 操作人 | 结果 |
|---|---|---|---|
| 2026-10-10 | Rancher Ingress 证书更换为新证书（secret `nginxssl-2026`） | （填写） | 源站新证书生效；3 个命名空间仍引用 `nginxssl-2024`（见 7.3） |
| 2026-10-12 | 高防平台（103.41.1.37）更换为新证书 | 学校老师 | 外网恢复，但证书链不完整（见 6.1、7.2） |
| 2026-10-12 | 内网 WAF 更换为新证书 | 学校老师 | 证书链是否完整待验证（见 7.2） |
| 2026-10-13 | WAF 上补齐中间证书 | （填写） | 移动立信 App 手机端登录恢复（见第 9 节）；链长复测见 8.1、8.4 |

### 5.2 待处置

1. **重新上传完整证书链（7.2）。** ~~在高防平台和内网 WAF 上重新上传完整证书链~~，**2026-10-13 已在 WAF 上补齐中间证书**（见第 9 节）。剩余工作：按 8.1、8.2、8.4 复测，确认高防和内网 WAF 两处的链长都已补齐。
2. **处理旧 secret 引用（7.3，须在 2026-10-23 前完成）。** 把仍引用 `nginxssl-2024` 的 Ingress 切换到新证书，并确认 `echo-server` 无 TLS 配置是否符合预期。
3. **确认 IPv6 入口（7.4）。** 确认 IPv6 入口节点的归属，以及上面的证书是否已更新。
4. **完善证书续期流程。** 在运维文档中明确：证书续期须同时更新以下位置，更新后按第 8 节方法从内外网分别验证。
   - Rancher Ingress secret（所有引用的命名空间）
   - 高防平台
   - 内网 WAF
   - IPv6 入口（如为独立服务）

   上传到高防和 WAF 时必须包含中间证书，验收标准为 `chain` ≥ 2（与源站一致为 3）。另外用 iOS Safari 或手机 App 实测一次。桌面浏览器会自动补全中间证书，不能作为验收依据（见 9.7）。

---

## 6. 换证后验证与核查（2026-10-12，v2 补充）

### 6.1 外网全量子域名验证

在外网服务器 mysql 上，对 3.9 的域名清单逐个取证书并统计证书链张数：

```text
[root@mysql ~]# while read -r h; do
>   ip=$(getent hosts "$h" | awk '{print $1}')
>   r=$(echo | timeout 8 openssl s_client -connect "$h:443" -servername "$h" -showcerts 2>/dev/null)
>   end=$(echo "$r" | openssl x509 -noout -enddate 2>/dev/null)
>   n=$(echo "$r" | grep -c 'BEGIN CERTIFICATE')
>   echo "$h  $ip  $end  chain=$n"
> done < /tmp/hosts.txt
admin-platform.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
authx-service.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
cas-minio.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
cas.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
cas.paas.lixin.edu.cn123      chain=0
ds.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:c4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
echo.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
form-design-m.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
form-design.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
form-space.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
formflow.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
governance-minio.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
message-service.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
personal-security-center.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
poa.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
portal-center-remote.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:c4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
portal-minio.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
portal-service.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
240e:f7:7c00:800:0:1:1:86
2409:8c28:30b0:b::1:b4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
portal-theme.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
question-feedback.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
stuwork.paas.lixin.edu.cn  2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
stuwork1.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
stuworkapp.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:c4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
superapp.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
token.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:86
240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
transaction.paas.lixin.edu.cn  240e:f7:7c00:800:0:1:1:c4
2409:8c28:30b0:b::1:b4
240e:f7:7c00:800:0:1:1:86  notAfter=Apr 26 15:59:59 2027 GMT  chain=1
[root@mysql ~]#
```

**分析：**

1. **新证书已在外网生效。** 25 个有效域名全部返回 `notAfter=Apr 26 15:59:59 2027 GMT`。`cas.paas.lixin.edu.cn123` 无法解析，`chain=0` 符合预期。
2. **证书链不完整。** 所有域名均为 `chain=1`：外网入口只下发了服务器证书，没有下发中间证书。桌面版 Chrome/Edge 会通过 AIA 自动补全，所以浏览器看着正常；但 Java、curl、Python、部分安卓 App、小程序，以及不能访问外网的 Windows 主机无法补全，会报证书不受信任。见 7.2。2026-10-13 已在移动立信 App 上出现该故障，见第 9 节。
3. **公网解析存在 IPv6（AAAA）记录。** 有 AAAA 记录时，`getent hosts` 只显示 IPv6 地址，所以输出中出现的都是 IPv6 地址（`240e:` 为电信段，`2409:8c28:` 为移动段），未显示 IPv4 的 103.41.1.37。本次无法判断 openssl 实际走的是 IPv4 还是 IPv6，IPv6 入口需要单独验证，见 7.4。

### 6.2 证书包核查（NGINX.zip，Rancher 中使用的证书）

证书包内容：`_.paas.lixin.edu.cn.cer`、`.crt`、`.pem`、`.key`，以及一个说明文件（证书安装参考：https://www.yuque.com/sheca/kfxgzb）。

```text
$ md5sum NGINX/*.cer NGINX/*.crt NGINX/*.pem
91f0a110f9453b1e2704fb3b2b4fd4ee  NGINX/_.paas.lixin.edu.cn.cer
91f0a110f9453b1e2704fb3b2b4fd4ee  NGINX/_.paas.lixin.edu.cn.crt
91f0a110f9453b1e2704fb3b2b4fd4ee  NGINX/_.paas.lixin.edu.cn.pem

$ for f in NGINX/*.cer NGINX/*.crt NGINX/*.pem; do echo "$f: $(grep -c "BEGIN CERTIFICATE" "$f")"; done
NGINX/_.paas.lixin.edu.cn.cer: 3
NGINX/_.paas.lixin.edu.cn.crt: 3
NGINX/_.paas.lixin.edu.cn.pem: 3
```

拆分为单张证书后逐张查看：

```text
$ cd NGINX && awk '/BEGIN CERT/{n++} {print > ("c" n ".pem")}' _.paas.lixin.edu.cn.crt
$ for i in 1 2 3; do echo "== cert $i"; openssl x509 -in c$i.pem -noout -subject -issuer -startdate -enddate -fingerprint -sha256; done
== cert 1
subject=CN = *.paas.lixin.edu.cn
issuer=C = CN, O = UniTrust, CN = SHECA DV TLS RSA CA A1
notBefore=Oct 10 07:50:28 2026 GMT
notAfter=Apr 26 15:59:59 2027 GMT
sha256 Fingerprint=AA:C6:69:78:DE:AA:B6:67:32:00:60:93:6A:33:0E:A1:97:DB:7F:99:38:88:65:4F:7C:C1:4E:34:5E:7C:8D:D2
== cert 2
subject=C = CN, O = UniTrust, CN = SHECA DV TLS RSA CA A1
issuer=C = CN, O = UniTrust, CN = UCA Global G2 Root
notBefore=Apr 27 16:00:00 2025 GMT
notAfter=Apr 27 15:59:59 2035 GMT
sha256 Fingerprint=7C:D1:3B:8B:9E:51:BD:6E:AE:01:16:D7:F8:9E:3F:21:EA:A3:AB:A2:A2:09:97:B2:60:6A:3D:CC:57:8E:72:95
== cert 3
subject=C = CN, O = UniTrust, CN = UCA Global G2 Root
issuer=C = PL, O = Unizeto Technologies S.A., OU = Certum Certification Authority, CN = Certum Trusted Network CA
notBefore=Jan  8 11:05:41 2024 GMT
notAfter=Jan  6 11:05:41 2029 GMT
sha256 Fingerprint=BF:A9:5C:5D:F1:64:B6:59:FA:32:F6:D1:05:64:D7:17:0D:DE:66:1A:85:3A:78:2E:6A:B6:36:39:43:3B:CB:41

$ openssl x509 -in c1.pem -noout -ext subjectAltName,authorityInfoAccess
X509v3 Subject Alternative Name:
    DNS:*.paas.lixin.edu.cn, DNS:paas.lixin.edu.cn
Authority Information Access:
    OCSP - URI:http://ocsp.global.sheca.com/gdvtlscaa1
    CA Issuers - URI:http://certs.global.sheca.com/gdvtlscaa1.cer
```

私钥与证书公钥比对，以及证书链校验（以第 3 张为信任锚）：

```text
$ openssl x509 -in c1.pem -noout -pubkey | openssl sha256
SHA2-256(stdin)= fd92c7c74952517fe9c175a76952b4ebc04da2ea3f7fcd90384e2035a58b4327
$ openssl pkey -in _.paas.lixin.edu.cn.key -pubout | openssl sha256
SHA2-256(stdin)= fd92c7c74952517fe9c175a76952b4ebc04da2ea3f7fcd90384e2035a58b4327

$ openssl verify -partial_chain -CAfile c3.pem -untrusted c2.pem c1.pem
c1.pem: OK
```

**结论：**

- **证书包完整。** `.cer`、`.crt`、`.pem` 内容相同，每个文件含 3 张证书，顺序正确：
  1. 服务器证书 `*.paas.lixin.edu.cn`（SAN 同时包含 `paas.lixin.edu.cn`），SHA-256 指纹与外网现在看到的一致，说明高防和 WAF 上换的是同一张证书；
  2. 中间证书 SHECA DV TLS RSA CA A1；
  3. 由 Certum Trusted Network CA 交叉签发的 UCA Global G2 Root，有效期至 2029-01-06。它用于兼容根证书库中没有 UCA Global G2 Root 的旧系统，例如 Windows 2012。
- **私钥匹配。** 私钥为 PKCS#8 格式（`BEGIN PRIVATE KEY`），2048 位 RSA，与服务器证书公钥一致；证书链校验通过。
- **高防返回 chain=1 的原因。** 证书包本身是完整的，所以问题出在上传环节：只有第 1 段生效。常见原因是控制台的"证书"和"证书链"是两个字段，或者控制台只解析了第一段 PEM。
- **私钥格式转换。** 如果控制台要求 `BEGIN RSA PRIVATE KEY`（PKCS#1）格式，用 `openssl rsa -in _.paas.lixin.edu.cn.key -out rsa.key` 转换，OpenSSL 3.x 需加 `-traditional`。

### 6.3 Rancher 侧证书链核查

```text
> kubectl -n formflow  get secret nginxssl-2026 -o jsonpath='{.data.tls\.crt}' | base64 -d | grep -c 'BEGIN CERTIFICATE'
3
```

```text
[root@nginx01 ~]# echo | openssl s_client -connect 202.121.255.182:443 -servername portal-theme.paas.lixin.edu.cn -showcerts 2>/dev/null | grep -c 'BEGIN CERTIFICATE'
3
```

**结论：**

- Rancher 中的 `nginxssl-2026`（formflow 命名空间）含完整 3 张证书，源站实际下发也是 3 张，Rancher 侧证书链完整。
- 3.4 中 nginx01 的 `Verify return code: 20` 与服务端无关，推断为 nginx01 本机信任库原因。
- 本次只核查了 formflow 命名空间的 secret。各命名空间中的同名 secret 是独立对象，其余命名空间在 7.3 中一并核查。

### 6.4 Rancher Ingress 证书引用核查

```text
> kubectl get ingress -A -o jsonpath='{range .items[*]}{.metadata.namespace}{" "}{.spec.tls[*].secretName}{"\n"}{end}' | sort -u
admin-platform nginxssl-2026
authx-service nginxssl-2024
authx-service-new nginxssl-2026
cas-server-new nginxssl-2026
dataassets nginxssl-2024
dataassets nginxssl-2026
echo-server
formflow nginxssl-2026
formflow-new nginxssl-2026
governance-minio nginxssl-2026
kube-system nginxssl-2026
message-service nginxssl-2026
platform-openapi nginxssl-2026
portal nginxssl-2026
portal-v6 nginxssl-2026
question-feedback nginxssl-2026
stuwork nginxssl-2024
transaction-center nginxssl-2026
```

**发现：**

1. **3 个命名空间仍引用旧 secret。** `authx-service`、`dataassets`、`stuwork` 中有 Ingress 仍引用 `nginxssl-2024`，其中 `dataassets` 同时存在引用新旧两个 secret 的 Ingress。
   - 外网访问经高防终结 TLS，因此 6.1 中这些域名在外网显示新证书。
   - 校内直接访问源站的用户，访问这些域名得到的是 `nginxssl-2024` 中的证书。如果它就是 2026-10-23 到期的旧证书，到期后这部分校内访问会直接报证书过期。
   - 这也是"两台内网机器仍显示旧证书"的可能原因之一（见 7.1）。
2. **echo-server 无 TLS 配置。** `echo-server` 命名空间的 Ingress 没有 TLS 配置，HTTPS 访问时 ingress-nginx 会使用默认证书，需确认是否符合预期。
3. **可能存在 host 冲突。** `authx-service`（旧 secret）与 `authx-service-new`（新 secret）可能声明了同一个 host。同一 host 被多个 Ingress 以不同 secret 声明时，最终生效的证书取决于 ingress-nginx 的合并规则，需要核对（见 7.3）。

### 6.5 堡垒机基线（Windows Server 2012 R2）

```text
PS C:\Users\Administrator> [Environment]::OSVersion.Version; $PSVersionTable.PSVersion

Major  Minor  Build  Revision
-----  -----  -----  --------
6      3      9600   0
4      0      -1     -1


PS C:\Users\Administrator> $h = 'portal-theme.paas.lixin.edu.cn'
PS C:\Users\Administrator> Resolve-DnsName $h | ? IPAddress | select Name, Type, IPAddress

Name                                                                       Type IPAddress
----                                                                       ---- ---------
portal-theme.paas.lixin.edu.cn                                                A 202.121.255.182


PS C:\Users\Administrator> Get-NetIPAddress -AddressFamily IPv6 -ErrorAction SilentlyContinue |  ? { $_.IPAddress -notli
ke 'fe80*' -and $_.IPAddress -ne '::1' -and $_.IPAddress -notlike '2001:0:*' -and $_.InterfaceAlias -notmatch 'Teredo|is
atap' } |  select IPAddress, InterfaceAlias

IPAddress                                                   InterfaceAlias
---------                                                   --------------
2002:ca79:ff99::ca79:ff99                                   6TO4 Adapter


PS C:\Users\Administrator> ping -n 1 $h

正在 Ping portal-theme.paas.lixin.edu.cn [202.121.255.182] 具有 32 字节的数据:
请求超时。

202.121.255.182 的 Ping 统计信息:
    数据包: 已发送 = 1，已接收 = 0，丢失 = 1 (100% 丢失)，
PS C:\Users\Administrator> Select-String lixin C:\Windows\System32\drivers\etc\hosts

C:\Windows\System32\drivers\etc\hosts:23:202.121.255.182 echo.paas.lixin.edu.cn
C:\Windows\System32\drivers\etc\hosts:25:202.121.255.121 fanruan.lixin.edu.cn


PS C:\Users\Administrator> netsh winhttp show proxy

当前的 WinHTTP 代理服务器设置:

    直接访问(没有代理服务器)。

PS C:\Users\Administrator> Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' | select
 ProxyEnable, ProxyServer, AutoConfigURL

                            ProxyEnable ProxyServer                             AutoConfigURL
                            ----------- -----------                             -------------
                                      0


PS C:\Users\Administrator> function Chk($ip, $sni, $port = 443) {
>>   $a   = [Net.IPAddress]::Parse($ip)
>>   $tcp = New-Object Net.Sockets.TcpClient($a.AddressFamily)
>>   try {
>>     $tcp.Connect($a, $port)
>>     $cb  = [Net.Security.RemoteCertificateValidationCallback]{ $true }
>>     $ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, $cb)
>>     $ssl.AuthenticateAsClient($sni, $null, [Security.Authentication.SslProtocols]::Tls12, $false)
>>     $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
>>     [pscustomobject]@{ IP = $ip; Issuer = ($c.Issuer -replace ',.*$', ''); NotAfter = $c.NotAfter; Error = '' }
>>   } catch {
>>     [pscustomobject]@{ IP = $ip; Issuer = 'FAILED'; NotAfter = $null; Error = $_.Exception.Message }
>>   } finally {
>>     $tcp.Close()
>>   }
>> }
>> (Resolve-DnsName $h | ? IPAddress).IPAddress | % { Chk $_ $h } | fl
>> Chk '202.121.255.182' $h | fl
>>


IP       : 202.121.255.182
Issuer   : CN=SHECA DV TLS RSA CA A1
NotAfter : 2027/4/26 23:59:59
Error    :


IP       : 202.121.255.182
Issuer   : CN=SHECA DV TLS RSA CA A1
NotAfter : 2027/4/26 23:59:59
Error    :
```

**分析：**

1. **系统版本：** 6.3.9600，即 Windows Server 2012 R2；PowerShell 4.0。
2. **解析：** 只返回 A 记录 202.121.255.182，没有 AAAA。说明校内 DNS 与公网解析不同，校内直接指向源站。
3. **IPv6：** 只有 6to4 隧道地址 `2002:ca79:ff99::ca79:ff99`，由本机公网 IPv4 202.121.255.153 派生（`ca79:ff99` = 202.121.255.153），不是原生 IPv6。Windows 默认前缀策略中 6to4 的优先级低于 IPv4，而且解析结果中也没有 AAAA，所以不会走 IPv6。原筛选条件没有排除 6to4，7.1 的脚本已补充。
4. **系统优先地址：** ping 显示使用的是 202.121.255.182。ICMP 不通不影响判断。
5. **hosts 与代理：**
   - hosts 中 `echo.paas.lixin.edu.cn` 指向 202.121.255.182，与 DNS 结果一致，无影响；
   - `fanruan.lixin.edu.cn` 与本平台无关；
   - 无 WinHTTP 代理，也无 IE 代理。
6. **证书：** 2012 R2 的系统 TLS 组件以 TLS 1.2 与源站握手成功，取到的是新证书（A1，至 2027-04-26）。

**结论：** 堡垒机直连源站，不经过高防和内网 WAF，结果正常，可作为两台异常机器的对照基线。

### 6.6 Windows 2012 / 2012 R2 命令兼容性说明

Windows Server 2012 自带 PowerShell 3.0，2012 R2 自带 PowerShell 4.0。

| 命令 | 2012 | 2012 R2 | 说明 |
|---|---|---|---|
| `Resolve-DnsName` | 可用 | 可用 | 结果包含 hosts 文件中的条目 |
| `? IPAddress` 简写 | 可用 | 可用 | PowerShell 3.0 起支持 |
| `Get-NetIPAddress` | 可用 | 可用 | 需排除 Teredo（`2001:0:`）、6to4（`2002:`）、ISATAP 等隧道地址 |
| `Test-NetConnection` | **不可用** | 可用 | 2012 R2 才引入；统一改用 `ping` 查看系统优先使用的地址 |
| `Select-String`、`netsh`、`Get-ItemProperty` | 可用 | 可用 | |
| `Chk` 函数 | 可用 | 可用（6.5 已验证） | 见下方注意事项 |

`Chk` 函数的注意事项：

- **依赖：** `[pscustomobject]` 需要 PowerShell 3.0；`Tls12` 需要 .NET 4.5，2012 自带。
- **握手可能失败：** 2012 / 2012 R2 的系统 TLS 组件不支持 TLS 1.3，支持的新加密套件也有限。服务端如果只开放较新的套件，函数会握手失败，但浏览器（Chrome 使用自带的 TLS 实现）不受影响。
- **区分失败原因：** 看 Error 字段，调用 `Connect` 时报错表示网络不通；调用 `AuthenticateAsClient` 时报错表示 TLS 握手失败。
- **执行方式：** 直接粘贴到 PowerShell 窗口执行，不要存成 .ps1（避免编码和执行策略问题）。每次新开一个窗口执行，避免复用之前的 TLS 会话。

---

## 7. 遗留与待核实事项

### 7.1 两台内网机器仍返回旧证书（待 2026-10-13 远程核查）

**现状：** 高防与内网 WAF 换证后外网已恢复，但内网有两台机器访问仍返回旧证书。这两台可能是 Windows 2012，暂时没有登录权限。

**可能原因：**

1. **访问的是仍引用旧 secret 的域名。** 如果它们访问的是 authx-service / dataassets / stuwork 相关域名，旧证书来自 Rancher 中仍引用的 `nginxssl-2024`（6.4、7.3）。**这一项可以先在堡垒机上验证**，用下方第 6 步对这些域名执行 `Chk` 即可。
2. **走了 IPv6。** 这两台有原生 IPv6，并解析到 AAAA 地址，走到了未更新证书的 IPv6 入口（7.4）。
3. **经过另一台 WAF。** 所在网段经过另一台或另一条策略、尚未更新证书的 WAF。
4. **客户端缓存。** 浏览器复用了换证前的 TLS 会话。IE 走系统 TLS 组件，客户端会话缓存默认保留约 10 小时；Chrome 可能有后台进程残留。
5. **hosts 或代理设置不同。**

**远程前先向老师确认：** 这两台机器访问的具体网址、使用的浏览器（IE 还是 Chrome）。

**在两台机器上执行**（直接粘贴到新开的 PowerShell 窗口；`$list` 中填入实际访问的域名）：

```powershell
# 0. 系统与 PowerShell 版本（6.2 = 2012，6.3 = 2012 R2）
[Environment]::OSVersion.Version; $PSVersionTable.PSVersion

$h    = 'portal-theme.paas.lixin.edu.cn'
$list = 'portal-theme.paas.lixin.edu.cn','stuwork.paas.lixin.edu.cn','authx-service.paas.lixin.edu.cn'

# 1. 解析结果（包含 hosts 文件中的条目）
$list | % { Resolve-DnsName $_ | ? IPAddress | select Name, Type, IPAddress }

# 2. 本机是否有原生 IPv6 地址（已排除链路本地、回环、Teredo、6to4、ISATAP）
Get-NetIPAddress -AddressFamily IPv6 -ErrorAction SilentlyContinue |
  ? { $_.IPAddress -notlike 'fe80*' -and $_.IPAddress -ne '::1' -and $_.IPAddress -notlike '2001:0:*' -and $_.IPAddress -notlike '2002:*' -and $_.InterfaceAlias -notmatch 'Teredo|isatap|6TO4' } |
  select IPAddress, InterfaceAlias

# 3. 系统优先使用的地址：看第一行方括号里的地址（ICMP 不通也能看到）
ping -n 1 $h

# 4. hosts 和代理
Select-String lixin C:\Windows\System32\drivers\etc\hosts
netsh winhttp show proxy
Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' | select ProxyEnable, ProxyServer, AutoConfigURL

# 5. 取证书函数
function Chk($ip, $sni, $port = 443) {
  $a   = [Net.IPAddress]::Parse($ip)
  $tcp = New-Object Net.Sockets.TcpClient($a.AddressFamily)
  try {
    $tcp.Connect($a, $port)
    $cb  = [Net.Security.RemoteCertificateValidationCallback]{ $true }
    $ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, $cb)
    $ssl.AuthenticateAsClient($sni, $null, [Security.Authentication.SslProtocols]::Tls12, $false)
    $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
    [pscustomobject]@{ IP = $ip; Issuer = ($c.Issuer -replace ',.*$', ''); NotAfter = $c.NotAfter; Error = '' }
  } catch {
    [pscustomobject]@{ IP = $ip; Issuer = 'FAILED'; NotAfter = $null; Error = $_.Exception.Message }
  } finally {
    $tcp.Close()
  }
}

# 6. 每个域名的每个解析地址分别取证书，再直连源站 IP 对照
$list | % { $d = $_; (Resolve-DnsName $d | ? IPAddress).IPAddress | % { Chk $_ $d | Add-Member -NotePropertyName Host -NotePropertyValue $d -PassThru } } | ft Host, IP, Issuer, NotAfter, Error -AutoSize
$list | % { Chk '202.121.255.182' $_ | Add-Member -NotePropertyName Host -NotePropertyValue $_ -PassThru } | ft Host, IP, Issuer, NotAfter, Error -AutoSize
```

如果 Error 列显示不全，对单个地址改用 `Chk <IP> <域名> | fl` 查看完整信息。

**判读：**

| 现象 | 结论 / 下一步 |
|---|---|
| 只有 stuwork / authx-service / dataassets 相关域名为旧证书（堡垒机上也一样） | Rancher 仍引用 `nginxssl-2024`，按 7.3 处理 |
| 旧证书只出现在 IPv6 地址上，且第 2 步有原生 IPv6 | IPv6 入口未换证，按 7.4 处理 |
| 直连 202.121.255.182 为旧证书，而堡垒机同一域名为新证书 | 该网段经过另一台或另一条策略的 WAF，请网络老师按网段排查 |
| `Chk` 全部为新证书，只有浏览器显示旧证书 | 客户端缓存。Chrome：任务管理器中确认无 chrome.exe 残留；IE：关闭所有窗口，仍旧则注销或重启 |
| hosts、代理或解析结果与堡垒机不同 | 按其指向排查 |

**核查结果：**（待补充）

### 7.2 高防 / 内网 WAF 证书链不完整

**现状：** 外网所有域名 `chain=1`（6.1），证书包本身为完整的 3 张（6.2），说明上传时只有服务器证书生效。内网 WAF 是否同样缺链尚未验证。

**影响（2026-10-13 确认）：** 移动立信 App 手机端登录报"网络错误"，iOS Safari 提示证书不受信任，见第 9 节。

**处置：**

- 在高防平台和内网 WAF 上重新上传 `_.paas.lixin.edu.cn.crt` 的全部内容（3 段）。
- 控制台有单独的"证书链 / CA 证书"字段时，第 2、3 段填入该字段。
- 私钥使用 `_.paas.lixin.edu.cn.key`。如要求 PKCS#1 格式，见 6.2 末尾的转换命令。

**验证：**

- 外网：按 8.1 执行，预期 `chain=3`（与 Rancher 一致，至少应为 2）。
- 内网 WAF：在其覆盖的网段内任选一台 Linux 主机，执行 8.4 的命令。

**结果：** 2026-10-13 已在 WAF 上补齐中间证书，移动立信 App 恢复正常（见第 9 节）。

| 设备 | 补链情况 | 复测 |
|---|---|---|
| 高防平台（103.41.1.37） | （填写） | 8.1、8.2：（待补充） |
| 内网 WAF | （填写） | 8.4：（待补充） |

### 7.3 Rancher 中仍引用 nginxssl-2024 的 Ingress，以及 echo-server 无 TLS

**须在 2026-10-23 前处理。**

**第一步：列出引用旧 secret 或未配置 TLS 的 Ingress，及其 host。**

```bash
kubectl get ingress -A -o jsonpath='{range .items[*]}{.metadata.namespace}{"\t"}{.metadata.name}{"\t"}{.spec.tls[*].secretName}{"\t"}{.spec.rules[*].host}{"\n"}{end}' > /tmp/ing.tsv
awk -F'\t' '$3=="" || $3 ~ /2024/' /tmp/ing.tsv
# 对上一条输出中的每个 host，检查是否同时被其他 Ingress 声明
grep -F '<host>' /tmp/ing.tsv
```

**第二步：查看旧 secret 的内容，并确认这些命名空间中是否已有新 secret。**

```bash
for ns in authx-service dataassets stuwork; do
  echo "== $ns"
  kubectl -n $ns get secret nginxssl-2024 -o jsonpath='{.data.tls\.crt}' | base64 -d \
    | openssl x509 -noout -issuer -enddate -fingerprint -sha256
  kubectl -n $ns get secret nginxssl-2026 >/dev/null 2>&1 && echo "nginxssl-2026: exists" || echo "nginxssl-2026: missing"
done
```

**第三步：在 nginx01 上对全部域名直连源站取证书，看校内用户实际拿到的证书。**

先把集群管理机上的 `/tmp/hosts.txt` 拷到 nginx01，并删除异常行（`sed -i '/123$/d' /tmp/hosts.txt`），然后执行：

```bash
while read -r h; do
  [ -z "$h" ] && continue
  r=$(echo | timeout 5 openssl s_client -connect 202.121.255.182:443 -servername "$h" -showcerts 2>/dev/null)
  iss=$(echo "$r" | openssl x509 -noout -issuer 2>/dev/null | sed 's/.*CN *= *//')
  end=$(echo "$r" | openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2)
  printf '%-44s %-28s %-26s chain=%s\n' "$h" "${iss:-FAILED}" "$end" "$(echo "$r" | grep -c 'BEGIN CERTIFICATE')"
done < /tmp/hosts.txt
```

**处置：**

- 在 Rancher UI 中为相关命名空间添加新证书（或使用项目级证书），再在对应负载均衡规则中改选新证书。
- 也可以用 kubectl 修改，前提是该命名空间中已有 `nginxssl-2026`：

```bash
kubectl -n <ns> get ingress <name> -o yaml > <name>.bak.yaml
kubectl -n <ns> patch ingress <name> --type=json -p='[{"op":"replace","path":"/spec/tls/0/secretName","value":"nginxssl-2026"}]'
```

处理后重新执行第三步，预期全部为新证书、`chain=3`。

`echo-server` 无 TLS 配置：确认该服务是否需要 HTTPS。如果需要，补充 TLS 配置并引用新证书。

**结果：**（待补充）

### 7.4 IPv6 入口节点未单独验证

**现状：** 公网存在 AAAA 记录（6.1），但 6.1 的测试无法区分走的是 IPv4 还是 IPv6。

**验证：**

1. 查询 IPv6 地址归属：

```bash
whois 240e:f7:7c00:800:0:1:1:86 | grep -iE 'netname|descr|org|country'
whois 2409:8c28:30b0:b::1:b4    | grep -iE 'netname|descr|org|country'
```

2. 在有 IPv6 出口的外网主机上执行 8.1 的逐地址循环。先用 `ip -6 route show default` 确认有默认路由。
3. 如果没有可用的 IPv6 主机，用 SSL Labs（ssllabs.com/ssltest）检测。它会对每个 IPv4 和 IPv6 地址分别测试，并报告链是否完整。

**结果：**（待补充）

### 7.5 ingress 访问日志中 `103.41.` 计数为 0

**现状：** nginx01 上有大量来自 103.41.164.x 的已建立连接（3.5），但 ingress 近 5 分钟日志中以 `103.41.` 开头的行为 0（3.8）。可能的原因有：

- 访问日志格式不以客户端地址开头；
- 访问日志被关闭；
- 客户端地址未从 proxy_protocol 中取值。

**核实命令：**

```bash
kubectl -n ingress-nginx logs nginx-ingress-controller-ffkdf --since=5m | grep -vE '^[IWE][0-9]{4}' | tail -3
kubectl -n ingress-nginx logs nginx-ingress-controller-ffkdf --since=5m | grep -c '103\.41\.'
kubectl -n ingress-nginx get cm nginx-configuration -o yaml | grep -iE 'proxy-protocol|forwarded|log-format|access-log|real-ip'
kubectl -n ingress-nginx get ds nginx-ingress-controller -o jsonpath='{..image}'; echo
```

**结果：**（待补充）

### 7.6 异常 Ingress host：`cas.paas.lixin.edu.cn123`

**现状：** Ingress 规则中存在该 host，疑似录入错误。

```bash
kubectl get ingress -A -o wide | grep 'cas.paas.lixin.edu.cn123'
```

**处理结果：**（待补充）

### 7.7 已关闭事项

| 原编号 | 事项 | 结论 |
|---|---|---|
| v1-6.2 | 图 4 外网终端远程地址为 202.121.255.182，却拿到旧证书、HTTP/1.1 | 已解释。老师确认内网 WAF 也持有旧证书并已更换，图 4 终端的访问路径经过内网 WAF，由其终结 TLS（依据老师确认的信息推断） |
| v1-6.3 | nginx01 本机 `Verify return code: 20` | 已关闭。Rancher secret 与源站下发均为完整 3 张证书（6.3），报错属 nginx01 本机信任库原因 |

---

## 8. 最终验证（待补充）

### 8.1 外网逐地址验证（IPv4 + IPv6）

在外网服务器上执行。先删除异常行：`sed -i '/123$/d' /tmp/hosts.txt`。

```bash
while read -r h; do
  [ -z "$h" ] && continue
  for ip in $( { getent ahostsv4 "$h"; getent ahostsv6 "$h" | grep -v '::ffff:'; } | awk '{print $1}' | sort -u ); do
    [[ $ip == *:* ]] && t="[$ip]:443" || t="$ip:443"
    r=$(echo | timeout 8 openssl s_client -connect "$t" -servername "$h" -showcerts 2>/dev/null)
    end=$(echo "$r" | openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2)
    n=$(echo "$r" | grep -c 'BEGIN CERTIFICATE')
    printf '%-44s %-28s %-26s chain=%s\n' "$h" "$ip" "${end:-FAILED}" "$n"
  done
done < /tmp/hosts.txt
```

**预期：** 每个域名的每个地址（103.41.1.37 及各 IPv6 地址）都显示 `Apr 26 15:59:59 2027 GMT` 和 `chain=3`。IPv6 地址如果全部为 FAILED，说明本机无 IPv6 出口，改用 7.4 的方法。

```text
（待补充）
```

### 8.2 直连高防节点验证（排除 DNS 缓存影响）

```bash
echo | openssl s_client -connect 103.41.1.37:443 -servername portal-theme.paas.lixin.edu.cn -showcerts 2>/dev/null \
  | grep -c 'BEGIN CERTIFICATE'
echo | openssl s_client -connect 103.41.1.37:443 -servername portal-theme.paas.lixin.edu.cn 2>/dev/null \
  | openssl x509 -noout -issuer -enddate -fingerprint -sha256
```

**预期：** 证书数为 3；SHA-256 指纹为 `AA:C6:69:78:DE:AA:B6:67:32:00:60:93:6A:33:0E:A1:97:DB:7F:99:38:88:65:4F:7C:C1:4E:34:5E:7C:8D:D2`。

```text
（待补充）
```

### 8.3 源站全域名验证（nginx01）

按 7.3 第三步执行。**预期：** 全部为 SHECA DV TLS RSA CA A1，到期 Apr 26 2027，`chain=3`。

```text
（待补充）
```

### 8.4 内网 WAF 路径验证

在经过内网 WAF 的网段内选一台主机，对同一域名取证书并统计链长。Linux 用 8.2 的命令把 IP 换成源站地址；Windows 用 7.1 的脚本。

```text
（待补充）
```

### 8.5 两台异常内网机器复测

按 7.1 的脚本复测，并用浏览器（彻底关闭后重新打开）查看证书。

```text
（待补充）
```

截图：（待补充）

### 8.6 移动端验证

按 9.6 第 4 步执行：安卓手机用蜂窝数据登录移动立信 App；iPhone 用 Safari 打开平台域名，不应出现证书告警。

```text
（待补充）
```

### 8.7 最终结论

（待补充）

---

## 9. 移动立信 App 手机端登录报"网络错误"（2026-10-13，v3 补充）

### 9.1 现象

| 项目 | 内容 |
|---|---|
| 报障时间 | 2026-10-13 09:24（录屏时间）；首次出现时间：（填写） |
| 应用 | 移动立信 App，H5 地址 `https://superapp.paas.lixin.edu.cn/pages/tab/index/index` |
| 现象 | 安卓手机打开 App，账号密码登录，点击"登录"后立即提示"网络错误"，无法登录 |
| 对照 | PC 浏览器打开同一地址（DevTools 手机模拟模式）页面正常，处于已登录状态 |
| 影响 | 手机端无法登录移动立信 App |

### 9.2 排查思路

PC 和手机的对比同时变了三个因素，需要分开看：

- **网络路径。** 手机走运营商蜂窝网络，必然经过公网入口（高防或 IPv6 入口）。PC 可能在堡垒机上直连源站，也可能经过高防或内网 WAF。
- **客户端 TLS 实现。** 桌面浏览器、iOS 系统 TLS、安卓 App 的网络库，在证书链校验上的行为不同。
- **操作。** PC 是浏览已登录的页面，手机是发起登录请求。

失败速度是关键线索。点击登录后约 0.25 秒就报错，说明不是超时或丢包，而是请求被立即拒绝。常见原因是 DNS 解析失败、TCP 被重置、TLS 证书校验失败。结合 6.1 外网全部域名 `chain=1`，首先怀疑证书链。

### 9.3 排查过程

#### 9.3.1 安卓 App 录屏分析

原始录屏：[attachments/android-app-login-network-error_20261013_0924.mp4](attachments/android-app-login-network-error_20261013_0924.mp4)（约 8 秒）。按 0.25 秒间隔抽帧：

| 录屏时间点 | 画面 | 说明 |
|---|---|---|
| 00:00 ～ 00:03.75 | 账号密码登录页，账号密码已填写 | 尚未点击 |
| 00:04.00 | "登录"按钮转圈 | 发起登录请求 |
| 00:04.25 | 转圈消失，"网络错误"提示开始出现 | 请求失败 |
| 00:04.50 ～ 00:07 | "网络错误"提示持续显示 | |

状态栏显示 4G/5G 双卡信号，没有 Wi-Fi 图标：手机走运营商蜂窝网络，按公网解析经高防或 IPv6 入口访问。

![图5 安卓 App 点击登录后约 0.25 秒提示"网络错误"（账号已打码）](images/fig5-android-app-login-network-error.png)

**分析：**

- 从发起请求到报错不超过约 0.25 秒，排除了超时和丢包。
- App 的登录页本身已打包在 App 内，登录请求是打开后的第一个网络请求，所以第一次联网就失败。

#### 9.3.2 PC 对照

PC 浏览器以手机模拟模式打开 `https://superapp.paas.lixin.edu.cn/pages/tab/index/index`，页面正常加载，显示首页内容和新闻列表（截至 2026-10-10 的资讯）。

![图6 PC 浏览器打开 superapp 首页正常](images/fig6-pc-superapp-index-ok.png)

PC 测试位置：（填写：堡垒机 / 外网终端）

**分析：** PC 正常有两种可能，都不会暴露缺链问题：

- **在堡垒机上测试：** 直连源站，源站下发完整的 3 张证书（6.3）。
- **经过高防或 WAF：** 桌面 Chrome/Edge 会按服务器证书中的 AIA 地址（`http://certs.global.sheca.com/gdvtlscaa1.cer`）自动下载中间证书并缓存。

所以"PC 正常"不能说明线上证书配置正确。

#### 9.3.3 iOS Safari 访问（09:41）

**测试条件：** iPhone，Wi-Fi（接入网络：（填写：校园网 / 外网）），Safari 打开 `https://superapp.paas.lixin.edu.cn`。

**结果：** Safari 提示"This Connection Is Not Private"。查看证书，显示 **Not Trusted**。

![图7 iOS Safari 提示连接不是私密连接，证书不受信任](images/fig7-ios-safari-cert-not-trusted.jpg)

证书详情（取自 iPhone 证书查看页）：

| 字段 | 值 | 判读 |
|---|---|---|
| 使用者 CN | `*.paas.lixin.edu.cn` | 与 `superapp.paas.lixin.edu.cn` 匹配 |
| 颁发者 | C=CN, O=UniTrust, CN=SHECA DV TLS RSA CA A1 | 新证书的中间 CA |
| 序列号 | `7D E5 D5 03 89 CC D6 FD 8C 51 DF D3 93 34 89 B7` | |
| 有效期 | 2026-10-10 15:50:28 ～ 2027-04-26 23:59:59 | 与 1.3 中的新证书一致，在有效期内 |
| 公钥 | RSA 2048 | |
| 密钥用法 | Digital Signature, Key Encipherment（Critical） | 正常 |
| 扩展密钥用法 | Server Authentication | 正常 |
| 颁发机构密钥标识（AKI） | `a4 43 6e e2 78 86 bc d3 d2 9b 43 06 b1 e6 05 ac 26 4f f4 71` | 应与中间证书的 SKI 一致（9.6 第 2 步） |
| 使用者密钥标识（SKI） | `9f db 2f 1f 92 07 8c fd a6 34 5c e8 83 71 7d d1 05 d9 82 5f` | |
| 证书策略 | 1.2.156.112570.1.1.1，CPS `https://www.sheca.com/repository` | |
| CRL | `http://crl.global.sheca.com/gdvtlscaa1.crl` | |
| AIA（OCSP） | `http://ocsp.global.sheca.com/gdvtlscaa1` | |
| AIA（CA Issuers） | `http://certs.global.sheca.com/gdvtlscaa1.cer` | 桌面浏览器据此自动下载中间证书 |
| 嵌入式 SCT | 有 | 满足证书透明度要求 |

![图8 iOS 证书详情：主体、有效期、AKI/SKI、AIA、SCT](images/fig8-ios-cert-details.jpg)

**分析：** 证书在有效期内，域名匹配，用途正确，带 SCT，iOS 仍然判定不受信任。排除这些因素后，剩下的原因是服务端只下发了服务器证书，没有下发中间证书 SHECA DV TLS RSA CA A1。iOS 不会自动下载中间证书，无法构建到根证书的信任路径。

#### 9.3.4 与已有证据关联

| 已有证据 | 来源 | 与本故障的关系 |
|---|---|---|
| 外网全部域名 `chain=1`，包括 `superapp.paas.lixin.edu.cn` | 6.1 | 外网入口只下发服务器证书 |
| 证书包含完整的 3 张证书，链校验通过 | 6.2 | 证书文件本身没问题，问题出在上传环节 |
| 源站下发 3 张证书 | 6.3 | Rancher 侧链完整，问题不在源站 |

### 9.4 根因

**WAF 上配置证书时缺少中间证书。** 2026-10-12 换证时只生效了服务器证书，客户端拿到的证书链只有 1 张。

各类客户端的表现差异：

| 客户端 | 是否自动补全中间证书 | 表现 |
|---|---|---|
| 桌面 Chrome / Edge（Windows） | 是，按 AIA 地址下载并缓存 | 正常 |
| iOS Safari | 否 | 提示连接不是私密连接，证书 Not Trusted |
| 安卓 App 的网络库 | 通常不会 | TLS 握手失败，App 统一提示"网络错误" |
| curl、Java、Python 等 | 否 | 报证书校验失败 |

**时间线推断：** 10-12 前高防出示的旧证书链完整，App 正常。10-12 换为新证书时缺中间证书，App 开始报错（首次报障时间待确认）。

### 9.5 处置

| 时间 | 操作 | 操作人 | 结果 |
|---|---|---|---|
| 2026-10-13 | 在 WAF 上补齐中间证书（具体方式：（填写）） | （填写） | 移动立信 App 手机端登录恢复 |

补链方法见 7.2：上传 `_.paas.lixin.edu.cn.crt` 的全部内容。如果控制台有单独的"证书链 / CA 证书"字段，把中间证书填入该字段。

平台所有域名共用同一张通配符证书，WAF 上补链后对全部 `*.paas.lixin.edu.cn` 域名生效，不只是 superapp。

### 9.6 验证

**1. 外网查看证书链（在外网 Linux 主机上执行）：**

```bash
echo | openssl s_client -connect superapp.paas.lixin.edu.cn:443 \
  -servername superapp.paas.lixin.edu.cn -showcerts 2>/dev/null \
  | grep -E '^ *[0-9] s:|Verify return code'
```

**预期：**

- 至少有 `0 s:CN = *.paas.lixin.edu.cn` 和 `1 s:C = CN, O = UniTrust, CN = SHECA DV TLS RSA CA A1` 两行。完整上传 3 段时还有 `2 s:...CN = UCA Global G2 Root`。
- `Verify return code: 0 (ok)`。如果本机信任库没有 UCA 根证书，可能显示 20（同 3.4），以 `s:` 行数为准。

```text
（待补充）
```

**2. 核对中间证书与服务器证书是否配对（使用 6.2 拆出的 `c2.pem`）：**

```bash
openssl x509 -in c2.pem -noout -subject -ext subjectKeyIdentifier
```

**预期：** subject 为 `CN = SHECA DV TLS RSA CA A1`，SKI 为 `A4:43:6E:E2:78:86:BC:D3:D2:9B:43:06:B1:E6:05:AC:26:4F:F4:71`，与 9.3.3 中服务器证书的 AKI 一致。

```text
（待补充）
```

**3. 全域名验证：** 按 8.1、8.2 执行，预期全部 `chain=3`（至少为 2）。内网 WAF 路径按 8.4 执行。

**4. 终端实测：**

| 测试 | 结果 |
|---|---|
| 安卓手机，蜂窝数据，移动立信 App 登录 | 已恢复（2026-10-13） |
| iPhone，Safari 打开 `https://superapp.paas.lixin.edu.cn` | （待补充，预期无证书告警） |

### 9.7 经验与预防

- **桌面浏览器正常，不等于证书部署正确。** Chrome/Edge 会自动补全中间证书，掩盖缺链问题。验收以 openssl 统计的链长（≥ 2）和移动端实测为准。
- **上传到 WAF / 高防时注意字段。** 部分控制台把"证书"和"证书链"分成两个字段，或只解析第一段 PEM（6.2）。上传后立即用 9.6 第 1 步检查。
- **移动端秒报"网络错误"，优先查连接和 TLS。** 立即失败而不是超时，优先排查 DNS、TCP、TLS。用 iPhone Safari 打开同一域名是最快的证书检查方法，会直接告警并可查看证书详情。
- **证书续期清单。** 见 5.2 第 4 条：Rancher、高防、内网 WAF、IPv6 入口都要更新，并从内外网分别验证。

**备用排查手段（本次未使用）：**

| 手段 | 方法 | 判读 |
|---|---|---|
| adb logcat | 手机开启 USB 调试，点击登录时执行 `adb logcat \| grep -iE "SSLHandshake\|CertPath\|Trust anchor\|UnknownHost\|CLEARTEXT"` | `Trust anchor for certification path not found` 为证书链或 CA 问题；`UnknownHostException` 为 DNS 问题。release 包不一定输出日志 |
| 热点抓包 | 手机连 PC 热点，Wireshark 过滤 `dns \|\| tls.handshake.type==1 \|\| tls.record.content_type==21 \|\| tcp.flags.reset==1` | 从 DNS 查询和 ClientHello 的 SNI 可以看出 App 连接的域名。握手后客户端发出 Alert，说明客户端拒绝证书；服务端发出 RST，说明被 WAF 或防火墙拦截 |
